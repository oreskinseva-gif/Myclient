package com.ezuk.client;

public enum Category {
    COMBAT("Combat", "Battle"),
    MOVEMENT("Movement", "Battle"),
    PLAYER("Player", "Battle"),
    RENDER("Render", "Visual"),
    MISC("Misc", "Other"),
    THEME("Theme", "Other");

    public final String title;
    public final String section;

    Category(String title, String section) {
        this.title = title;
        this.section = section;
    }
}
