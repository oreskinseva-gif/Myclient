package com.ezuk.client.modules;

import com.ezuk.client.Category;
import com.ezuk.client.Module;
import com.ezuk.client.setting.BoolSetting;
import com.ezuk.client.setting.ModeSetting;
import com.ezuk.client.util.CombatUtil;
import com.ezuk.client.util.Theme;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Esp extends Module {
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting mobs = add(new BoolSetting("Mobs", true));
    public final BoolSetting animals = add(new BoolSetting("Animals", false));
    public final ModeSetting color = add(new ModeSetting("Color", "Accent", "Red", "White"));

    public Esp() { super("ESP", Category.RENDER); }

    public void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider vcp = ctx.consumers();
        if (mc.world == null || mc.player == null || ms == null || vcp == null) return;

        float r, g, b;
        if (color.is("Red")) { r = 1f; g = 0.3f; b = 0.3f; }
        else if (color.is("White")) { r = 1f; g = 1f; b = 1f; }
        else {
            int c = Theme.accent();
            r = ((c >> 16) & 255) / 255f; g = ((c >> 8) & 255) / 255f; b = (c & 255) / 255f;
        }

        Vec3d cam = ctx.camera().getPos();
        float td = mc.getRenderTickCounter().getTickDelta(false);
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getLines());

        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);
        for (Entity e : mc.world.getEntities()) {
            if (!CombatUtil.isValid(mc, e, players.get(), mobs.get(), animals.get())) continue;
            double ox = MathHelper.lerp(td, e.prevX, e.getX()) - e.getX();
            double oy = MathHelper.lerp(td, e.prevY, e.getY()) - e.getY();
            double oz = MathHelper.lerp(td, e.prevZ, e.getZ()) - e.getZ();
            Box box = e.getBoundingBox().offset(ox, oy, oz);
            VertexRendering.drawBox(ms, vc, box, r, g, b, 1f);
        }
        ms.pop();
        if (vcp instanceof VertexConsumerProvider.Immediate imm) imm.draw(RenderLayer.getLines());
    }
}
