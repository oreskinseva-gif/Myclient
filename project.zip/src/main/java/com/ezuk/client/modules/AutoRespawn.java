package com.ezuk.client.modules;

import com.ezuk.client.Category;
import com.ezuk.client.Module;
import net.minecraft.client.MinecraftClient;

public class AutoRespawn extends Module {
    public AutoRespawn() { super("AutoRespawn", Category.PLAYER); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player.isDead()) mc.player.requestRespawn();
    }
}
