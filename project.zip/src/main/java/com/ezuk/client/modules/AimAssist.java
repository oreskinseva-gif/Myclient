package com.ezuk.client.modules;

import com.ezuk.client.Category;
import com.ezuk.client.Module;
import com.ezuk.client.setting.BoolSetting;
import com.ezuk.client.setting.NumberSetting;
import com.ezuk.client.util.CombatUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;

public class AimAssist extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 4.5, 2.0, 6.0, 0.1));
    public final NumberSetting fov = add(new NumberSetting("FOV", 90, 20, 360, 10));
    public final NumberSetting speed = add(new NumberSetting("Speed", 6, 1, 30, 1));
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting mobs = add(new BoolSetting("Mobs", false));
    public final BoolSetting onClick = add(new BoolSetting("Only on click", true));

    public AimAssist() { super("AimAssist", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null) return;
        if (onClick.get() && !mc.options.attackKey.isPressed()) return;
        LivingEntity t = CombatUtil.findTarget(mc, range.get(), (float) fov.get(),
                players.get(), mobs.get(), false, false);
        if (t == null) return;
        float[] r = CombatUtil.rotationTo(mc, t);
        CombatUtil.rotateToward(mc, r[0], r[1], (float) speed.get());
    }
}
