package com.ezuk.client.modules;

import com.ezuk.client.Category;
import com.ezuk.client.Module;
import com.ezuk.client.setting.Setting;

/** Модуль, который только включает отрисовку виджета в Hud. */
public class HudModule extends Module {
    public HudModule(String name) { super(name, Category.RENDER); }

    public <T extends Setting> T with(T s) { return add(s); }
}
