package com.ezuk.client.modules;

import com.ezuk.client.Category;
import com.ezuk.client.Module;
import com.ezuk.client.setting.BoolSetting;
import com.ezuk.client.setting.NumberSetting;
import com.ezuk.client.util.CombatUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;

/** Увеличивает хитбоксы целей на клиенте: по ним легче попасть. */
public class Hitbox extends Module {
    public final NumberSetting size = add(new NumberSetting("Size", 0.2, 0.0, 1.0, 0.05));
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting mobs = add(new BoolSetting("Mobs", false));

    public Hitbox() { super("Hitbox", Category.COMBAT); }

    private static Box base(Entity e) {
        return e.getDimensions(e.getPose()).getBoxAt(e.getPos());
    }

    @Override
    public void onTick(MinecraftClient mc) {
        double s = size.get();
        for (Entity e : mc.world.getEntities()) {
            if (!CombatUtil.isValid(mc, e, players.get(), mobs.get(), false)) continue;
            e.setBoundingBox(base(e).expand(s, s * 0.5, s));
        }
    }

    @Override
    public void onDisable(MinecraftClient mc) {
        for (Entity e : mc.world.getEntities()) {
            if (e != mc.player) e.setBoundingBox(base(e));
        }
    }
}
