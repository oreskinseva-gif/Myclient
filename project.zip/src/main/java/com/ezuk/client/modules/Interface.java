package com.ezuk.client.modules;

import com.ezuk.client.Category;
import com.ezuk.client.Module;
import com.ezuk.client.setting.BoolSetting;
import com.ezuk.client.setting.NumberSetting;

public class Interface extends Module {
    public final BoolSetting watermark = add(new BoolSetting("Watermark", true));
    public final BoolSetting arrayList = add(new BoolSetting("Module list", true));
    public final BoolSetting blur = add(new BoolSetting("Blur", true));
    public final NumberSetting glass = add(new NumberSetting("Transparency", 0.55, 0.2, 0.9, 0.05));
    public final NumberSetting hue = add(new NumberSetting("Color", 140, 0, 360, 1));

    public Interface() {
        super("Interface", Category.THEME);
        enableSilently();
    }
}
