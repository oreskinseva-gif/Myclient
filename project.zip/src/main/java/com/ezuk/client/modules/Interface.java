package com.ezuk.client.modules;

import com.ezuk.client.Category;
import com.ezuk.client.Module;
import com.ezuk.client.setting.BoolSetting;
import com.ezuk.client.setting.NumberSetting;

public class Interface extends Module {
    public final BoolSetting watermark = add(new BoolSetting("Watermark", true));
    public final BoolSetting arrayList = add(new BoolSetting("Module list", true));
    public final NumberSetting hue = add(new NumberSetting("Color", 270, 0, 360, 1));

    public Interface() {
        super("Interface", Category.RENDER);
        enableSilently();
    }
}
