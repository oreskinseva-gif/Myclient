package com.ezuk.client.modules;

import com.ezuk.client.Category;
import com.ezuk.client.Module;
import com.ezuk.client.setting.BoolSetting;
import com.ezuk.client.setting.NumberSetting;
import com.ezuk.client.util.CombatUtil;
import com.ezuk.client.util.Rotations;
import net.minecraft.block.Block;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.FallingBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class Scaffold extends Module {
    public final NumberSetting expand = add(new NumberSetting("Expand", 0, 0, 4, 1));
    public final NumberSetting delay = add(new NumberSetting("Delay (ticks)", 0, 0, 5, 1));
    public final BoolSetting tower = add(new BoolSetting("Tower", true));
    public final BoolSetting rotate = add(new BoolSetting("Rotate", true));
    public final BoolSetting silent = add(new BoolSetting("Silent", true));
    public final BoolSetting switchBack = add(new BoolSetting("Switch back", true));

    private int prevSlot = -1;
    private int cooldown;
    private boolean silentActive;

    public Scaffold() { super("Scaffold", Category.PLAYER); }

    @Override
    public void onEnable(MinecraftClient mc) { prevSlot = mc.player.getInventory().selectedSlot; }

    @Override
    public void onDisable(MinecraftClient mc) {
        if (silentActive) { Rotations.restore(mc); silentActive = false; }
        if (switchBack.get() && prevSlot >= 0) mc.player.getInventory().selectedSlot = prevSlot;
        prevSlot = -1;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null || mc.interactionManager == null) return;
        if (cooldown > 0) { cooldown--; return; }
        int slot = findBlockSlot(mc);
        if (slot < 0) return;

        boolean moving = mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed()
                || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed();
        double yaw = Math.toRadians(mc.player.getYaw());
        double dx = moving ? -Math.sin(yaw) : 0, dz = moving ? Math.cos(yaw) : 0;

        boolean placed = false;
        int ex = (int) expand.get();
        for (int i = 0; i <= ex && !placed; i++) {
            BlockPos pos = BlockPos.ofFloored(mc.player.getX() + dx * i, mc.player.getY() - 1, mc.player.getZ() + dz * i);
            if (!mc.world.getBlockState(pos).isReplaceable()) continue;
            placed = tryPlace(mc, pos, slot);
        }

        if (!placed && silentActive) { Rotations.restore(mc); silentActive = false; }
        if (placed) cooldown = (int) delay.get();
        if (tower.get() && mc.options.jumpKey.isPressed() && !moving && (placed || mc.player.isOnGround())) {
            Vec3d v = mc.player.getVelocity();
            mc.player.setVelocity(v.x, 0.42, v.z);
        }
    }

    private boolean tryPlace(MinecraftClient mc, BlockPos pos, int slot) {
        for (Direction dir : Direction.values()) {
            BlockPos nb = pos.offset(dir);
            if (mc.world.getBlockState(nb).isReplaceable()) continue;
            Direction face = dir.getOpposite();
            Vec3d hitVec = new Vec3d(nb.getX() + 0.5 + face.getOffsetX() * 0.5,
                    nb.getY() + 0.5 + face.getOffsetY() * 0.5,
                    nb.getZ() + 0.5 + face.getOffsetZ() * 0.5);
            if (rotate.get()) {
                float[] r = CombatUtil.rotationTo(mc, hitVec);
                if (silent.get()) {
                    Rotations.sendSilent(mc, r[0], r[1]);
                    silentActive = true;
                } else {
                    CombatUtil.rotateToward(mc, r[0], r[1], 180f);
                }
            }
            mc.player.getInventory().selectedSlot = slot;
            ActionResult res = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                    new BlockHitResult(hitVec, face, nb, false));
            if (res.isAccepted()) {
                mc.player.swingHand(Hand.MAIN_HAND);
                return true;
            }
        }
        return false;
    }

    private int findBlockSlot(MinecraftClient mc) {
        int cur = mc.player.getInventory().selectedSlot;
        if (isGoodBlock(mc, mc.player.getInventory().getStack(cur))) return cur;
        for (int i = 0; i < 9; i++) {
            if (isGoodBlock(mc, mc.player.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    private boolean isGoodBlock(MinecraftClient mc, ItemStack s) {
        if (s.isEmpty() || !(s.getItem() instanceof BlockItem bi)) return false;
        Block b = bi.getBlock();
        if (b instanceof BlockWithEntity || b instanceof FallingBlock) return false;
        return b.getDefaultState().isFullCube(mc.world, BlockPos.ORIGIN);
    }
}
