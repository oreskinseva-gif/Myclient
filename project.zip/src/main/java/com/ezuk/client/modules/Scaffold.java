package com.ezuk.client.modules;

import com.ezuk.client.Category;
import com.ezuk.client.Module;
import com.ezuk.client.setting.BoolSetting;
import com.ezuk.client.setting.ModeSetting;
import com.ezuk.client.setting.NumberSetting;
import com.ezuk.client.util.CombatUtil;
import com.ezuk.client.util.Rotations;
import net.minecraft.block.Block;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.FallingBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Scaffold extends Module {
    public final ModeSetting mode = add(new ModeSetting("Mode", "Normal", "Ninja", "Telly"));
    public final NumberSetting cps = add(new NumberSetting("CPS", 12, 1, 20, 1));
    public final NumberSetting expand = add(new NumberSetting("Expand", 0, 0, 4, 1));
    public final NumberSetting turn = add(new NumberSetting("Turn speed", 45, 10, 180, 5));
    public final BoolSetting rotate = add(new BoolSetting("Rotate", true));
    public final BoolSetting silent = add(new BoolSetting("Silent", true));
    public final BoolSetting smooth = add(new BoolSetting("Smooth", true));
    public final BoolSetting tower = add(new BoolSetting("Tower", true));
    public final BoolSetting switchBack = add(new BoolSetting("Switch back", true));

    private static class Plan { BlockPos nb; Direction face; Vec3d hit; }

    private int prevSlot = -1;
    private double credit;
    private boolean active;
    private float sy, sp;

    public Scaffold() { super("Scaffold", Category.PLAYER); }

    @Override
    public void onEnable(MinecraftClient mc) {
        prevSlot = mc.player.getInventory().selectedSlot;
        credit = 1.0;
        active = false;
    }

    @Override
    public void onDisable(MinecraftClient mc) {
        if (active) { Rotations.restore(mc); active = false; }
        if (mode.is("Ninja")) mc.options.sneakKey.setPressed(false);
        if (switchBack.get() && prevSlot >= 0) mc.player.getInventory().selectedSlot = prevSlot;
        prevSlot = -1;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null || mc.interactionManager == null) return;
        credit = Math.min(2.0, credit + cps.get() / 20.0);

        int slot = findBlockSlot(mc);
        if (slot < 0) { relax(mc); return; }

        boolean moving = mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed()
                || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed();
        double yaw = Math.toRadians(mc.player.getYaw());
        double dx = moving ? -Math.sin(yaw) : 0, dz = moving ? Math.cos(yaw) : 0;
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();

        boolean ninja = mode.is("Ninja"), telly = mode.is("Telly");

        if (telly && moving) {
            if (mc.player.isOnGround()) mc.player.jump();
            mc.player.setSprinting(true);
        }
        if (ninja) {
            // присесть у края, чтобы не упасть, и ставить блок вперёд
            boolean edge = moving && mc.player.isOnGround()
                    && mc.world.getBlockState(BlockPos.ofFloored(px + dx * 0.4, py - 1, pz + dz * 0.4)).isReplaceable();
            mc.options.sneakKey.setPressed(edge);
        }

        int[] offsets;
        if (ninja) offsets = new int[]{1, 0};
        else if (telly) offsets = new int[]{0};
        else {
            offsets = new int[(int) expand.get() + 1];
            for (int i = 0; i < offsets.length; i++) offsets[i] = i;
        }

        Plan plan = null;
        for (int i : offsets) {
            BlockPos pos = BlockPos.ofFloored(px + dx * i, py - 1, pz + dz * i);
            if (!mc.world.getBlockState(pos).isReplaceable()) continue;
            plan = makePlan(mc, pos);
            if (plan != null) break;
        }
        if (plan == null) { relax(mc); return; }

        // плавный поворот к точке установки
        if (rotate.get()) {
            float[] r = CombatUtil.rotationTo(mc, plan.hit);
            float step = smooth.get() ? (float) turn.get() : 180f;
            boolean aimed;
            if (silent.get()) {
                if (!active) { sy = mc.player.getYaw(); sp = mc.player.getPitch(); active = true; }
                sy += MathHelper.clamp(MathHelper.wrapDegrees(r[0] - sy), -step, step);
                sp = MathHelper.clamp(sp + MathHelper.clamp(r[1] - sp, -step, step), -90f, 90f);
                Rotations.sendSilent(mc, sy, sp);
                aimed = Math.abs(MathHelper.wrapDegrees(r[0] - sy)) < 12f && Math.abs(r[1] - sp) < 14f;
            } else {
                CombatUtil.rotateToward(mc, r[0], r[1], step);
                aimed = CombatUtil.yawError(mc, r[0]) < 12f && Math.abs(r[1] - mc.player.getPitch()) < 14f;
            }
            if (!aimed) return;
        }

        if (credit < 1.0) return;

        mc.player.getInventory().selectedSlot = slot;
        ActionResult res = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                new BlockHitResult(plan.hit, plan.face, plan.nb, false));
        if (res.isAccepted()) {
            mc.player.swingHand(Hand.MAIN_HAND);
            credit -= 1.0;
            if (tower.get() && !telly && mc.options.jumpKey.isPressed() && !moving) {
                Vec3d v = mc.player.getVelocity();
                mc.player.setVelocity(v.x, 0.42, v.z);
            }
        }
    }

    /** Плавно вернуть повернутую модель к реальному углу камеры. */
    private void relax(MinecraftClient mc) {
        if (!active) return;
        if (!smooth.get()) { Rotations.restore(mc); active = false; return; }
        float step = (float) turn.get();
        sy += MathHelper.clamp(MathHelper.wrapDegrees(mc.player.getYaw() - sy), -step, step);
        sp += MathHelper.clamp(mc.player.getPitch() - sp, -step, step);
        Rotations.sendSilent(mc, sy, sp);
        if (Math.abs(MathHelper.wrapDegrees(mc.player.getYaw() - sy)) < 2f
                && Math.abs(mc.player.getPitch() - sp) < 2f) {
            Rotations.restore(mc);
            active = false;
        }
    }

    private Plan makePlan(MinecraftClient mc, BlockPos pos) {
        Vec3d eye = mc.player.getEyePos();
        for (Direction dir : Direction.values()) {
            BlockPos nb = pos.offset(dir);
            if (mc.world.getBlockState(nb).isReplaceable()) continue;
            Direction face = dir.getOpposite();
            Vec3d hit = new Vec3d(nb.getX() + 0.5 + face.getOffsetX() * 0.5,
                    nb.getY() + 0.5 + face.getOffsetY() * 0.5,
                    nb.getZ() + 0.5 + face.getOffsetZ() * 0.5);
            if (eye.distanceTo(hit) > 4.5) continue;
            Plan p = new Plan();
            p.nb = nb; p.face = face; p.hit = hit;
            return p;
        }
        return null;
    }

    private int findBlockSlot(MinecraftClient mc) {
        int cur = mc.player.getInventory().selectedSlot;
        if (isGoodBlock(mc, mc.player.getInventory().getStack(cur))) return cur;
        for (int i = 0; i < 9; i++) {
            if (isGoodBlock(mc, mc.player.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    private boolean isGoodBlock(MinecraftClient mc, ItemStack s) {
        if (s.isEmpty() || !(s.getItem() instanceof BlockItem bi)) return false;
        Block b = bi.getBlock();
        if (b instanceof BlockWithEntity || b instanceof FallingBlock) return false;
        return b.getDefaultState().isFullCube(mc.world, BlockPos.ORIGIN);
    }
}
