package com.ezuk.client.modules;

import com.ezuk.client.Category;
import com.ezuk.client.Module;
import com.ezuk.client.setting.BoolSetting;
import com.ezuk.client.setting.ModeSetting;
import com.ezuk.client.setting.NumberSetting;
import com.ezuk.client.util.CombatUtil;
import com.ezuk.client.util.Rotations;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;

public class KillAura extends Module {
    public final ModeSetting mode = add(new ModeSetting("Mode", "Free", "Focused"));
    public final NumberSetting range = add(new NumberSetting("Range", 3.8, 2.0, 6.0, 0.1));
    public final NumberSetting fov = add(new NumberSetting("FOV", 180, 30, 360, 10));
    public final NumberSetting speed = add(new NumberSetting("Turn speed", 60, 10, 180, 5));
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting mobs = add(new BoolSetting("Mobs", true));
    public final BoolSetting animals = add(new BoolSetting("Animals", false));
    public final BoolSetting rotate = add(new BoolSetting("Rotate", true));
    public final BoolSetting silent = add(new BoolSetting("Silent", true));
    public final BoolSetting crits = add(new BoolSetting("Crits", false));
    public final BoolSetting walls = add(new BoolSetting("Through walls", false));

    public LivingEntity current;
    private LivingEntity locked;
    private boolean has;
    private float sy, sp;

    public KillAura() { super("KillAura", Category.COMBAT); }

    @Override
    public void onDisable(MinecraftClient mc) {
        current = null;
        locked = null;
        if (has) Rotations.restore(mc);
        has = false;
    }

    /** Free: всегда ближайшая цель. Focused: держимся за выбранную, пока она жива и рядом. */
    private LivingEntity pick(MinecraftClient mc) {
        if (!mode.is("Focused")) { locked = null; return find(mc); }
        if (locked != null) {
            boolean ok = locked.isAlive() && !locked.isRemoved()
                    && mc.player.distanceTo(locked) <= range.get() * 1.25
                    && CombatUtil.isValid(mc, locked, players.get(), mobs.get(), animals.get());
            if (ok) return locked;
            locked = null;
        }
        HitResult hit = mc.crosshairTarget;
        if (hit != null && hit.getType() == HitResult.Type.ENTITY
                && ((EntityHitResult) hit).getEntity() instanceof LivingEntity le
                && CombatUtil.isValid(mc, le, players.get(), mobs.get(), animals.get())
                && mc.player.distanceTo(le) <= range.get()) {
            locked = le;
        } else {
            locked = find(mc);
        }
        return locked;
    }

    private LivingEntity find(MinecraftClient mc) {
        return CombatUtil.findTarget(mc, range.get(), (float) fov.get(),
                players.get(), mobs.get(), animals.get(), walls.get());
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null || mc.interactionManager == null) return;
        LivingEntity t = pick(mc);
        current = t;
        if (t == null) {
            if (has) { has = false; Rotations.restore(mc); }
            return;
        }

        boolean aimed = true;
        if (rotate.get()) {
            float[] r = CombatUtil.rotationTo(mc, t);
            float step = (float) speed.get();
            if (silent.get()) {
                if (!has) { sy = mc.player.getYaw(); sp = mc.player.getPitch(); has = true; }
                sy += MathHelper.clamp(MathHelper.wrapDegrees(r[0] - sy), -step, step);
                sp = MathHelper.clamp(sp + MathHelper.clamp(r[1] - sp, -step, step), -90f, 90f);
                Rotations.sendSilent(mc, sy, sp);
                aimed = Math.abs(MathHelper.wrapDegrees(r[0] - sy)) < 15f;
            } else {
                CombatUtil.rotateToward(mc, r[0], r[1], step);
                aimed = CombatUtil.yawError(mc, r[0]) < 25f;
            }
        }
        if (!aimed) return;

        if (mc.player.getAttackCooldownProgress(0.5f) < 1.0f) return;

        if (crits.get() && !mc.player.isTouchingWater() && !mc.player.isClimbing()) {
            if (mc.player.isOnGround()) { mc.player.jump(); return; }
            if (mc.player.fallDistance <= 0f) return;
        }

        mc.interactionManager.attackEntity(mc.player, t);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
