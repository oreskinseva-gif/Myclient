package com.ezuk.client.modules;

import com.ezuk.client.Category;
import com.ezuk.client.Module;
import com.ezuk.client.setting.BoolSetting;
import com.ezuk.client.setting.NumberSetting;
import com.ezuk.client.util.CombatUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;

public class KillAura extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 3.8, 2.0, 6.0, 0.1));
    public final NumberSetting fov = add(new NumberSetting("FOV", 180, 30, 360, 10));
    public final NumberSetting speed = add(new NumberSetting("Turn speed", 60, 10, 180, 5));
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting mobs = add(new BoolSetting("Mobs", true));
    public final BoolSetting animals = add(new BoolSetting("Animals", false));
    public final BoolSetting rotate = add(new BoolSetting("Rotate", true));
    public final BoolSetting crits = add(new BoolSetting("Crits", false));
    public final BoolSetting walls = add(new BoolSetting("Through walls", false));

    public KillAura() { super("KillAura", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null || mc.interactionManager == null) return;
        LivingEntity t = CombatUtil.findTarget(mc, range.get(), (float) fov.get(),
                players.get(), mobs.get(), animals.get(), walls.get());
        if (t == null) return;

        if (rotate.get()) {
            float[] r = CombatUtil.rotationTo(mc, t);
            CombatUtil.rotateToward(mc, r[0], r[1], (float) speed.get());
            if (CombatUtil.yawError(mc, r[0]) > 25f) return; // ещё не навелись
        }

        if (mc.player.getAttackCooldownProgress(0.5f) < 1.0f) return;

        if (crits.get() && !mc.player.isTouchingWater() && !mc.player.isClimbing()) {
            if (mc.player.isOnGround()) { mc.player.jump(); return; }
            if (mc.player.fallDistance <= 0f) return; // ждём падения для крита
        }

        mc.interactionManager.attackEntity(mc.player, t);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
