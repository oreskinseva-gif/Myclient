package com.ezuk.client;

import com.ezuk.client.modules.*;
import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> modules = new ArrayList<>();
    public static Interface ui;

    public static void init() {
        ui = new Interface();
        modules.add(new KillAura());
        modules.add(new AimAssist());
        modules.add(new TriggerBot());
        modules.add(new Velocity());
        modules.add(new AutoTotem());
        modules.add(new Sprint());
        modules.add(new Fly());
        modules.add(new BHop());
        modules.add(ui);
        modules.add(new FullBright());
        modules.add(new Scaffold());
        modules.add(new AutoRespawn());
        modules.add(new AntiAFK());
    }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) if (m.category == c) out.add(m);
        return out;
    }
}
