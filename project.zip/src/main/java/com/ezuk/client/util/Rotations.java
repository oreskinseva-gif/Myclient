package com.ezuk.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.MathHelper;

public final class Rotations {
    private Rotations() {}

    /**
     * Тихий поворот: камера остаётся на месте, а сервер (и модель персонажа) получают новый угол.
     * Тело и голова модели поворачиваются визуально.
     */
    public static void sendSilent(MinecraftClient mc, float yaw, float pitch) {
        ClientPlayNetworkHandler h = mc.getNetworkHandler();
        if (h == null || mc.player == null) return;
        pitch = MathHelper.clamp(pitch, -90f, 90f);
        h.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                yaw, pitch, mc.player.isOnGround(), mc.player.horizontalCollision));
        mc.player.bodyYaw = yaw;
        mc.player.prevBodyYaw = yaw;
        mc.player.headYaw = yaw;
        mc.player.prevHeadYaw = yaw;
    }

    /** Вернуть серверу реальный угол камеры. */
    public static void restore(MinecraftClient mc) {
        if (mc.player != null) sendSilent(mc, mc.player.getYaw(), mc.player.getPitch());
    }
}
