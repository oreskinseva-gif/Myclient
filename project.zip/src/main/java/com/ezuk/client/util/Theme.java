package com.ezuk.client.util;

import com.ezuk.client.ModuleManager;

public final class Theme {
    private Theme() {}

    public static int accent() { return accent(0); }

    /** Акцентный цвет; shift даёт плавный сдвиг оттенка (для волны в списке модулей). */
    public static int accent(float shift) {
        float hue = (float) ModuleManager.ui.hue.get() / 360f + shift;
        return Draw.hsb(hue, 0.55f, 1f);
    }
}
