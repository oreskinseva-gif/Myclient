package com.ezuk.client;

import com.ezuk.client.gui.ClickGuiScreen;
import com.ezuk.client.gui.Hud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class EzukClient implements ClientModInitializer {
    public static final String NAME = "Ezuk";
    private static boolean menuWasDown;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null || mc.world == null) return;
            menuKey(mc);
            for (Module m : ModuleManager.modules) {
                if (m.isEnabled()) m.onTick(mc);
            }
        });
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> Hud.render(ctx));
    }

    /** Правый Shift открывает меню (в FCL можно повесить на экранную кнопку). */
    private static void menuKey(MinecraftClient mc) {
        if (mc.currentScreen != null) { menuWasDown = true; return; }
        boolean down = InputUtil.isKeyPressed(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT);
        if (down && !menuWasDown) mc.setScreen(new ClickGuiScreen());
        menuWasDown = down;
    }
}
