package com.ezuk.client.gui;

import com.ezuk.client.Module;
import com.ezuk.client.ModuleManager;
import com.ezuk.client.modules.Interface;
import com.ezuk.client.util.Draw;
import com.ezuk.client.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Hud {
    private static long last = System.nanoTime();

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        if (mc.player == null || mc.options.hudHidden) return;

        TextRenderer tr = mc.textRenderer;
        Interface ui = ModuleManager.ui;
        int acc = Theme.accent();

        // Вотермарка
        if (ui.isEnabled() && ui.watermark.get()) {
            String brand = "Ezuk";
            String rest = " client  |  " + mc.getSession().getUsername() + "  |  " + mc.getCurrentFps() + " fps";
            int w = tr.getWidth(brand) + tr.getWidth(rest) + 12;
            Draw.rrect(ctx, 4, 4, w, 15, 4, Draw.argb(0x101015, 0.82f));
            Draw.rrect(ctx, 4, 6, 2, 11, 1, Draw.argb(acc, 1f));
            Draw.text(ctx, tr, brand, 10, 8, acc, 1f);
            Draw.text(ctx, tr, rest, 10 + tr.getWidth(brand), 8, 0xB4B4C0, 1f);
        }

        // Список включённых модулей с анимацией выезда
        List<Module> shown = new ArrayList<>();
        for (Module m : ModuleManager.modules) {
            boolean want = m.isEnabled() && ui.isEnabled() && ui.arrayList.get() && m != ui;
            m.listAnim.to(want ? 1f : 0f, 12f, dt);
            if (m.listAnim.v > 0.01f) shown.add(m);
        }
        shown.sort(Comparator.comparingInt((Module m) -> -tr.getWidth(m.name)));

        int sw = ctx.getScaledWindowWidth();
        int y = 4;
        int i = 0;
        for (Module m : shown) {
            float a = Draw.ease(m.listAnim.v);
            int w = tr.getWidth(m.name) + 10;
            int x = sw - w - 4 + Math.round((1f - a) * (w + 6));
            int rowH = Math.round(12 * a);
            int col = Theme.accent(i * 0.015f);
            Draw.rrect(ctx, x, y, w, 11, 3, Draw.argb(0x101015, 0.78f * a));
            Draw.rrect(ctx, x + w - 2, y + 1, 2, 9, 1, Draw.argb(col, a));
            Draw.text(ctx, tr, m.name, x + 4, y + 2, col, a);
            y += rowH;
            i++;
        }
    }
}
