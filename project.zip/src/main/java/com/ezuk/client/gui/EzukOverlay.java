package com.ezuk.client.gui;

import com.ezuk.client.util.Draw;
import com.ezuk.client.util.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Overlay;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;

/**
 * Загрузочный экран Ezuk: вместо красного фона Mojang картинка с логотипом.
 * Стандартная загрузка работает под ним как обычно и сама закрывает экран.
 */
public class EzukOverlay extends Overlay {
    private static final Identifier BG = Identifier.of("ezuk", "textures/gui/background.png");
    private static final int TW = 1920, TH = 1080;

    private final Overlay inner;
    private final long start = System.currentTimeMillis();

    public EzukOverlay(Overlay inner) { this.inner = inner; }

    public boolean pausesGame() { return inner.pausesGame(); }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        inner.render(ctx, mouseX, mouseY, delta); // идёт настоящая загрузка ресурсов

        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        // картинка «cover»: заполняет экран без искажений, лишнее обрезается по краям
        float screenAspect = (float) sw / sh, texAspect = (float) TW / TH;
        int rw = TW, rh = TH;
        float u = 0f, v = 0f;
        if (screenAspect > texAspect) { rh = Math.round(TW / screenAspect); v = (TH - rh) / 2f; }
        else { rw = Math.round(TH * screenAspect); u = (TW - rw) / 2f; }
        ctx.drawTexture(RenderLayer::getGuiTextured, BG, 0, 0, u, v, sw, sh, rw, rh, TW, TH);

        // полоса загрузки (прогресс плавно «подползает», пока ресурсы грузятся)
        float t = (System.currentTimeMillis() - start) / 1000f;
        float p = Math.min(0.96f, 1f - (float) Math.exp(-t / 4.5f));
        int bw = Math.min(180, sw / 2), bx = (sw - bw) / 2, by = Math.round(sh * 0.80f);
        Draw.rrect(ctx, bx, by, bw, 4, 2, Draw.argb(0xFFFFFF, 0.18f));
        Draw.rrect(ctx, bx, by, Math.max(4, Math.round(bw * p)), 4, 2, Draw.argb(Theme.accent(), 1f));
    }
}
