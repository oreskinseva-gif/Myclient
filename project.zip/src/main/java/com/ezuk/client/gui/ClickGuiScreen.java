package com.ezuk.client.gui;

import com.ezuk.client.Category;
import com.ezuk.client.Module;
import com.ezuk.client.ModuleManager;
import com.ezuk.client.setting.BoolSetting;
import com.ezuk.client.setting.ModeSetting;
import com.ezuk.client.setting.NumberSetting;
import com.ezuk.client.setting.Setting;
import com.ezuk.client.util.Anim;
import com.ezuk.client.util.Draw;
import com.ezuk.client.util.Theme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Прозрачное «стеклянное» меню в стиле iOS: размытый фон, закруглённые карточки, переключатели-тумблеры. */
public class ClickGuiScreen extends Screen {
    private static Category selected = Category.COMBAT;
    private static final int HH = 26, GAP = 6;

    private static class Chip { ModeSetting mo; int idx, x, y, w, h; }

    private final Anim open = new Anim(0), switchCat = new Anim(1), scroll = new Anim(0), searchAnim = new Anim(0);
    private final Anim tabX = new Anim(0), tabW = new Anim(0);
    private final Anim[] catSel = new Anim[Category.values().length];
    private final int[] tabXs = new int[Category.values().length], tabWs = new int[Category.values().length];
    private final List<Chip> chips = new ArrayList<>();
    private final StringBuilder query = new StringBuilder();
    private List<Module> visible = new ArrayList<>();

    private boolean closing, searching, init;
    private float scrollTarget, maxScroll;
    private long last = System.nanoTime();
    private int wx, wy, ww, wh, gx, gw, gy, gh, pillX, pillW;
    private int pressArea;
    private double pressX, pressY, moved;
    private NumberSetting dragSlider;

    public ClickGuiScreen() {
        super(Text.literal("Ezuk"));
        for (int i = 0; i < catSel.length; i++) catSel[i] = new Anim(Category.values()[i] == selected ? 1f : 0f);
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void close() { closing = true; }
    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) {}

    // ------------------------------------------------------------ клавиатура
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (searching) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) { stopSearch(); return true; }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (query.length() > 0) query.setLength(query.length() - 1);
                return true;
            }
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT && !searching) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searching && chr >= 32 && query.length() < 24) {
            query.append(chr);
            scrollTarget = 0f;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    private void stopSearch() { searching = false; query.setLength(0); }

    // ------------------------------------------------------------ раскладка настроек
    private static int modeRows(TextRenderer tr, ModeSetting mo, int innerW) {
        int rows = 1, cx = 0;
        for (String m : mo.modes) {
            int w = tr.getWidth(m) + 14;
            if (cx + w > innerW && cx > 0) { rows++; cx = 0; }
            cx += w + 4;
        }
        return rows;
    }

    private static int settingH(TextRenderer tr, Setting s, int w) {
        if (s instanceof NumberSetting) return 32;
        if (s instanceof ModeSetting mo) return 15 + modeRows(tr, mo, w - 20) * 20 + 3;
        return 24;
    }

    private static int settingsHeight(TextRenderer tr, Module m, int w) {
        if (m.settings.isEmpty()) return 0;
        int h = 10;
        for (Setting s : m.settings) h += settingH(tr, s, w);
        return h;
    }

    // ------------------------------------------------------------ рендер
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;

        open.to(closing ? 0f : 1f, 12f, dt);
        if (closing && open.v < 0.03f) { client.setScreen(null); return; }
        float a = Draw.ease(open.v);

        TextRenderer tr = client.textRenderer;
        int acc = Theme.accent();
        var ui = ModuleManager.ui;
        float g = (float) ui.glass.get();

        // размытие мира за меню (настоящее стекло) + лёгкое затемнение
        if (ui.blur.get()) applyBlur();
        ctx.fill(0, 0, width, height, Draw.argb(0x000000, 0.20f * a));

        ww = Math.min(480, width - 12);
        wh = Math.min(272, height - 12);
        wx = (width - ww) / 2;
        wy = (height - wh) / 2 + Math.round((1f - a) * 14f);

        // мягкая тень
        for (int k = 3; k >= 1; k--) {
            Draw.rrect(ctx, wx - k * 2, wy - k * 2 + 4, ww + k * 4, wh + k * 4, 14 + k * 2, Draw.argb(0x000000, 0.05f * a));
        }
        // стеклянное окно
        Draw.rrect(ctx, wx, wy, ww, wh, 14, Draw.argb(0x141922, g * a));
        Draw.rrect(ctx, wx, wy, ww, wh, 14, Draw.argb(0xFFFFFF, 0.04f * a));
        Draw.outline(ctx, wx, wy, ww, wh, 14, Draw.argb(0xFFFFFF, 0.22f * a));
        ctx.fill(wx + 14, wy + 1, wx + ww - 14, wy + 2, Draw.argb(0xFFFFFF, 0.26f * a));

        drawHeader(ctx, tr, a, acc, dt);

        gx = wx + 10;
        gw = ww - 20;
        gy = wy + 42;
        gh = wh - 42 - 10;
        switchCat.to(1f, 12f, dt);
        drawGrid(ctx, tr, mouseX, mouseY, a * switchCat.v, acc, dt);
    }

    private void drawHeader(DrawContext ctx, TextRenderer tr, float a, int acc, float dt) {
        // иконка приложения
        Draw.rrect(ctx, wx + 12, wy + 9, 22, 22, 7, Draw.argb(acc, a));
        Draw.logoE(ctx, wx + 18, wy + 15, 10, 0x10131A, a);
        Draw.text(ctx, tr, "Ezuk", wx + 40, wy + 16, 0xFFFFFF, a);
        int titleEnd = wx + 40 + tr.getWidth("Ezuk") + 14;

        // поиск (пилюля справа, раскрывается на всю шапку)
        searchAnim.to(searching ? 1f : 0f, 14f, dt);
        int right = wx + ww - 12, pillMin = 78;
        pillW = pillMin + Math.round(searchAnim.v * ((right - titleEnd) - pillMin));
        pillX = right - pillW;
        Draw.rrect(ctx, pillX, wy + 9, pillW, 22, 11, Draw.argb(0xFFFFFF, (0.09f + 0.05f * searchAnim.v) * a));
        Draw.outline(ctx, pillX, wy + 9, pillW, 22, 11, Draw.argb(Draw.mix(0xFFFFFF, acc, searchAnim.v), (0.16f + 0.3f * searchAnim.v) * a));
        int ic = Draw.mix(0xA8ACB8, acc, searchAnim.v);
        Draw.outline(ctx, pillX + 8, wy + 15, 9, 9, 4, Draw.argb(ic, a));
        ctx.fill(pillX + 16, wy + 23, pillX + 19, wy + 25, Draw.argb(ic, a));
        if (searching) {
            boolean caret = (System.currentTimeMillis() / 500) % 2 == 0;
            String q = query.length() == 0 ? "Search..." : query.toString();
            int col = query.length() == 0 ? 0x7D8190 : 0xFFFFFF;
            String shown = tr.trimToWidth(q, pillW - 36);
            Draw.text(ctx, tr, shown, pillX + 24, wy + 16, col, a);
            if (caret && query.length() > 0) {
                int cx = pillX + 24 + tr.getWidth(shown);
                ctx.fill(cx + 1, wy + 15, cx + 2, wy + 25, Draw.argb(acc, a));
            }
        } else {
            Draw.text(ctx, tr, "Search", pillX + 24, wy + 16, 0x7D8190, a * (1f - searchAnim.v));
        }

        // вкладки в «сегментированном контроле»
        Category[] cats = Category.values();
        int total = 0;
        for (Category c : cats) total += tr.getWidth(c.title);
        int tabsEnd = right - pillMin - 10;
        int pad = Math.max(3, Math.min(7, (tabsEnd - titleEnd - 6 - total) / (cats.length * 2)));
        int cx = titleEnd + 3;
        for (int i = 0; i < cats.length; i++) {
            tabXs[i] = cx;
            tabWs[i] = tr.getWidth(cats[i].title) + pad * 2;
            cx += tabWs[i];
        }
        int si = selected.ordinal();
        if (!init) { tabX.v = tabXs[si]; tabW.v = tabWs[si]; init = true; }
        tabX.to(tabXs[si], 16f, dt);
        tabW.to(tabWs[si], 16f, dt);

        float ta = a * (1f - searchAnim.v);
        if (ta > 0.03f) {
            int cw0 = cx - titleEnd + 3;
            Draw.rrect(ctx, titleEnd, wy + 9, cw0, 22, 11, Draw.argb(0xFFFFFF, 0.08f * ta));
            Draw.outline(ctx, titleEnd, wy + 9, cw0, 22, 11, Draw.argb(0xFFFFFF, 0.13f * ta));
            Draw.rrect(ctx, Math.round(tabX.v), wy + 11, Math.round(tabW.v), 18, 9, Draw.argb(acc, 0.38f * ta));
            Draw.outline(ctx, Math.round(tabX.v), wy + 11, Math.round(tabW.v), 18, 9, Draw.argb(acc, 0.65f * ta));
            for (int i = 0; i < cats.length; i++) {
                catSel[i].to(i == si ? 1f : 0f, 14f, dt);
                Draw.text(ctx, tr, cats[i].title, tabXs[i] + pad, wy + 16, Draw.mix(0xA8ACB8, 0xFFFFFF, catSel[i].v), ta);
            }
        }
    }

    private void refreshVisible() {
        if (searching && query.length() > 0) {
            String q = query.toString().toLowerCase(Locale.ROOT);
            List<Module> out = new ArrayList<>();
            for (Module m : ModuleManager.modules) if (m.name.toLowerCase(Locale.ROOT).contains(q)) out.add(m);
            visible = out;
        } else {
            visible = ModuleManager.byCategory(selected);
        }
    }

    private void drawGrid(DrawContext ctx, TextRenderer tr, int mouseX, int mouseY, float ca, int acc, float dt) {
        refreshVisible();
        chips.clear();

        int cols = gw >= 400 ? 3 : 2;
        int colW = (gw - GAP * (cols - 1)) / cols;
        float[] colY = new float[cols];

        for (int i = 0; i < visible.size(); i++) {
            Module m = visible.get(i);
            m.toggleAnim.to(m.isEnabled() ? 1f : 0f, 14f, dt);
            m.expandAnim.to(m.expanded && !m.settings.isEmpty() ? 1f : 0f, 14f, dt);
            int c = i % cols;
            int h = HH;
            if (!m.settings.isEmpty()) h += Math.round(m.expandAnim.v * (settingsHeight(tr, m, colW) + 4));
            m.uiX = gx + c * (colW + GAP);
            m.uiW = colW;
            m.uiH = h;
            m.uiY = Math.round(colY[c]);
            colY[c] += h + GAP;
        }
        float contentH = 0;
        for (float v : colY) contentH = Math.max(contentH, v - GAP);
        maxScroll = Math.max(0f, contentH - gh);
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
        scroll.to(scrollTarget, 22f, dt);
        float slide = (1f - Draw.ease(switchCat.v)) * 8f;

        if (visible.isEmpty()) {
            String s = searching ? "Nothing found" : "Coming soon";
            Draw.text(ctx, tr, s, gx + (gw - tr.getWidth(s)) / 2, gy + gh / 2 - 4, 0x7D8190, ca);
        }

        ctx.enableScissor(gx - 2, gy, gx + gw + 2, gy + gh);
        for (Module m : visible) {
            m.uiY = Math.round(gy + m.uiY - scroll.v + slide);
            boolean hov = mouseX >= m.uiX && mouseX < m.uiX + m.uiW && mouseY >= m.uiY && mouseY < m.uiY + HH
                    && mouseY >= gy && mouseY < gy + gh;
            m.hoverAnim.to(hov ? 1f : 0f, 16f, dt);
            if (m.uiY + m.uiH >= gy && m.uiY <= gy + gh) drawCard(ctx, tr, m, ca, acc, dt);
        }
        ctx.disableScissor();

        if (maxScroll > 0f) {
            int sbh = Math.max(14, Math.round(gh * gh / contentH));
            int sby = gy + Math.round((gh - sbh) * (scroll.v / maxScroll));
            Draw.rrect(ctx, gx + gw + 3, sby, 2, sbh, 1, Draw.argb(0xFFFFFF, 0.35f * ca));
        }
    }

    private static void ios(DrawContext ctx, int x, int y, int w, int h, float on, int acc, float a) {
        Draw.rrect(ctx, x, y, w, h, h / 2, Draw.argb(Draw.mix(0x787880, acc, on), (0.42f + 0.58f * on) * a));
        int k = h - 2, kx = x + 1 + Math.round(on * (w - k - 2));
        Draw.rrect(ctx, kx, y + 2, k, k, k / 2, Draw.argb(0x000000, 0.25f * a));
        Draw.rrect(ctx, kx, y + 1, k, k, k / 2, Draw.argb(0xFFFFFF, a));
    }

    private void drawCard(DrawContext ctx, TextRenderer tr, Module m, float ca, int acc, float dt) {
        int x = m.uiX, y = m.uiY, w = m.uiW, h = m.uiH;
        float tg = m.toggleAnim.v, ex = m.expandAnim.v;

        Draw.rrect(ctx, x, y, w, h, 10, Draw.argb(Draw.mix(0xFFFFFF, acc, 0.45f * tg), (0.07f + 0.04f * m.hoverAnim.v + 0.10f * tg) * ca));
        Draw.outline(ctx, x, y, w, h, 10, Draw.argb(Draw.mix(0xFFFFFF, acc, 0.7f * tg), (0.10f + 0.32f * tg) * ca));
        Draw.text(ctx, tr, tr.trimToWidth(m.name, w - 66), x + 11, y + 9, Draw.mix(0xB8BCC8, 0xFFFFFF, tg), ca);

        ios(ctx, x + w - 34, y + 6, 26, 14, tg, acc, ca);
        if (!m.settings.isEmpty()) {
            int dc = Draw.mix(0x80848F, acc, ex);
            for (int i = 0; i < 3; i++) ctx.fill(x + w - 56 + i * 4, y + 12, x + w - 54 + i * 4, y + 14, Draw.argb(dc, ca));
        }

        if (ex > 0.02f) {
            ctx.enableScissor(x, Math.max(y, gy), x + w, Math.min(y + h, gy + gh));
            float ea = ca * ex;
            ctx.fill(x + 10, y + HH, x + w - 10, y + HH + 1, Draw.argb(0xFFFFFF, 0.09f * ea));
            int ry = y + HH + 5;
            for (Setting s : m.settings) {
                int sh = settingH(tr, s, w);
                s.ux = x; s.uy = ry; s.uw = w; s.uh = sh;
                if (s instanceof BoolSetting b) {
                    b.anim.to(b.get() ? 1f : 0f, 16f, dt);
                    Draw.text(ctx, tr, tr.trimToWidth(b.name, w - 50), x + 10, ry + 8, 0xD6D9E2, ea);
                    ios(ctx, x + w - 32, ry + 5, 22, 12, b.anim.v, acc, ea);
                } else if (s instanceof NumberSetting n) {
                    n.ux = x + 10; n.uw = w - 20;
                    n.anim.to(n.frac(), 22f, dt);
                    String vs = n.step >= 1 ? String.valueOf((int) Math.round(n.get()))
                            : String.format(Locale.ROOT, "%.2f", n.get());
                    Draw.text(ctx, tr, n.name, x + 10, ry + 2, 0xD6D9E2, ea);
                    Draw.text(ctx, tr, vs, x + w - 10 - tr.getWidth(vs), ry + 2, acc, ea);
                    int fw = Math.round(n.anim.v * n.uw);
                    Draw.rrect(ctx, n.ux, ry + 19, n.uw, 4, 2, Draw.argb(0xFFFFFF, 0.20f * ea));
                    if (fw > 0) Draw.rrect(ctx, n.ux, ry + 19, fw, 4, 2, Draw.argb(acc, ea));
                    Draw.rrect(ctx, n.ux + fw - 5, ry + 18, 10, 10, 5, Draw.argb(0x000000, 0.25f * ea));
                    Draw.rrect(ctx, n.ux + fw - 5, ry + 16, 10, 10, 5, Draw.argb(0xFFFFFF, ea));
                } else if (s instanceof ModeSetting mo) {
                    Draw.text(ctx, tr, mo.name, x + 10, ry + 2, 0xD6D9E2, ea);
                    int cxp = x + 10, cyp = ry + 15;
                    for (int i = 0; i < mo.modes.length; i++) {
                        int tw = tr.getWidth(mo.modes[i]) + 14;
                        if (cxp + tw > x + w - 10 && cxp > x + 10) { cxp = x + 10; cyp += 20; }
                        boolean sel = i == mo.index();
                        Draw.rrect(ctx, cxp, cyp, tw, 16, 8, Draw.argb(sel ? acc : 0xFFFFFF, sel ? 0.42f * ea : 0.10f * ea));
                        if (sel) Draw.outline(ctx, cxp, cyp, tw, 16, 8, Draw.argb(acc, 0.7f * ea));
                        Draw.text(ctx, tr, mo.modes[i], cxp + 7, cyp + 4, sel ? 0xFFFFFF : 0xA8ACB8, ea);
                        Chip c = new Chip();
                        c.mo = mo; c.idx = i; c.x = cxp; c.y = cyp; c.w = tw; c.h = 16;
                        chips.add(c);
                        cxp += tw + 4;
                    }
                }
                ry += sh;
            }
            ctx.disableScissor();
        }
    }

    // ------------------------------------------------------------ ввод
    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void select(Category c) {
        stopSearch();
        if (c == selected) return;
        selected = c;
        switchCat.v = 0f;
        scrollTarget = 0f;
        scroll.v = 0f;
    }

    private void setSlider(NumberSetting s, double mx) {
        double f = Math.max(0.0, Math.min(1.0, (mx - s.ux) / (double) s.uw));
        double raw = s.min + f * (s.max - s.min);
        s.set(Math.round(raw / s.step) * s.step);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (open.v < 0.9f || closing) return true;
        if (!in(mx, my, wx, wy, ww, wh)) { close(); return true; }

        if (my >= wy + 8 && my < wy + 32) {
            if (in(mx, my, pillX, wy + 9, pillW, 22)) {
                if (!searching) searching = true;
                else if (mx < pillX + 24) stopSearch();
                return true;
            }
            if (searchAnim.v < 0.5f) {
                Category[] cats = Category.values();
                for (int i = 0; i < cats.length; i++) {
                    if (mx >= tabXs[i] && mx < tabXs[i] + tabWs[i]) { select(cats[i]); return true; }
                }
            }
            return true;
        }

        pressArea = 0;
        if (in(mx, my, gx, gy, gw, gh)) {
            for (Module m : visible) {
                if (m.expandAnim.v < 0.6f) continue;
                for (Setting s : m.settings) {
                    if (s instanceof NumberSetting n && in(mx, my, n.ux - 6, n.uy + 14, n.uw + 12, 16)
                            && in(mx, my, m.uiX, m.uiY, m.uiW, m.uiH)) {
                        dragSlider = n;
                        setSlider(n, mx);
                        return true;
                    }
                }
            }
            pressArea = 1;
            pressX = mx; pressY = my; moved = 0;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragSlider != null) { setSlider(dragSlider, mx); return true; }
        if (pressArea == 1) {
            moved += Math.abs(dx) + Math.abs(dy);
            scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) dy));
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragSlider != null) { dragSlider = null; return true; }
        int area = pressArea;
        pressArea = 0;
        if (area == 1 && moved < 6) tap(pressX, pressY);
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) v * 22f));
        return true;
    }

    private void tap(double mx, double my) {
        for (Module m : visible) {
            if (!in(mx, my, m.uiX, m.uiY, m.uiW, m.uiH)) continue;
            if (my < m.uiY + HH) {
                boolean dots = !m.settings.isEmpty() && mx >= m.uiX + m.uiW - 62 && mx < m.uiX + m.uiW - 38;
                if (dots) m.expanded = !m.expanded; else m.toggle();
                return;
            }
            if (m.expandAnim.v > 0.6f) {
                for (Chip c : chips) {
                    if (in(mx, my, c.x, c.y, c.w, c.h)) { c.mo.set(c.idx); return; }
                }
                for (Setting s : m.settings) {
                    if (s instanceof BoolSetting b && in(mx, my, b.ux, b.uy, b.uw, b.uh)) { b.toggle(); return; }
                }
            }
            return;
        }
    }
}
