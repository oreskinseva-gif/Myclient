package com.ezuk.client.gui;

import com.ezuk.client.Category;
import com.ezuk.client.Module;
import com.ezuk.client.ModuleManager;
import com.ezuk.client.setting.BoolSetting;
import com.ezuk.client.setting.NumberSetting;
import com.ezuk.client.setting.Setting;
import com.ezuk.client.util.Anim;
import com.ezuk.client.util.Draw;
import com.ezuk.client.util.Theme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.List;
import java.util.Locale;

public class ClickGuiScreen extends Screen {
    private static Category selected = Category.MOVEMENT;
    private static final int SW = 84; // ширина боковой панели

    private final Anim open = new Anim(0);
    private final Anim pill = new Anim(0);
    private final Anim scroll = new Anim(0);
    private final Anim switchCat = new Anim(1);
    private final Anim[] catSel = new Anim[Category.values().length];
    private float scrollTarget, maxScroll;
    private boolean closing;
    private long last = System.nanoTime();

    private int wx, wy, ww, wh, viewX, viewY, viewW, viewH;
    private boolean pressing;
    private double px, py, moved;
    private NumberSetting dragSlider;

    public ClickGuiScreen() {
        super(Text.literal("Ezuk"));
        for (int i = 0; i < catSel.length; i++) catSel[i] = new Anim(Category.values()[i] == selected ? 1f : 0f);
        pill.v = selected.ordinal() * 24;
    }

    @Override public boolean shouldPause() { return false; }

    @Override public void close() { closing = true; }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) { /* свой фон */ }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    // ------------------------------------------------------------ рендер
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;

        open.to(closing ? 0f : 1f, 12f, dt);
        if (closing && open.v < 0.03f) { client.setScreen(null); return; }
        float a = Draw.ease(open.v);

        TextRenderer tr = client.textRenderer;
        int acc = Theme.accent();
        ctx.fill(0, 0, width, height, Draw.argb(0x000000, 0.55f * a));

        ww = Math.min(360, width - 12);
        wh = Math.min(224, height - 12);
        wx = (width - ww) / 2;
        wy = (height - wh) / 2 + Math.round((1f - a) * 16f);

        // окно
        Draw.rrect(ctx, wx - 1, wy - 1, ww + 2, wh + 2, 9, Draw.argb(acc, 0.28f * a));
        Draw.rrect(ctx, wx, wy, ww, wh, 8, Draw.argb(0x121217, a));
        Draw.rrect(ctx, wx + 4, wy + 4, SW - 4, wh - 8, 6, Draw.argb(0x0C0C10, a));

        // логотип
        Draw.text(ctx, tr, "Ezuk", wx + 14, wy + 12, acc, a);
        Draw.text(ctx, tr, "client", wx + 17 + tr.getWidth("Ezuk"), wy + 12, 0x8A8A96, a);

        // категории + плавная подсветка
        Category[] cats = Category.values();
        pill.to(selected.ordinal() * 24f, 16f, dt);
        int py0 = wy + 36 + Math.round(pill.v);
        Draw.rrect(ctx, wx + 8, py0, SW - 12, 20, 5, Draw.argb(acc, 0.20f * a));
        Draw.rrect(ctx, wx + 8, py0 + 4, 2, 12, 1, Draw.argb(acc, a));
        for (int i = 0; i < cats.length; i++) {
            catSel[i].to(cats[i] == selected ? 1f : 0f, 14f, dt);
            Draw.text(ctx, tr, cats[i].title, wx + 18, wy + 36 + i * 24 + 6,
                    Draw.mix(0x8A8A96, 0xFFFFFF, catSel[i].v), a);
        }
        Draw.text(ctx, tr, "v1.0", wx + 14, wy + wh - 16, 0x55555F, a);

        // контент
        viewX = wx + SW + 8;
        viewY = wy + 30;
        viewW = ww - SW - 16;
        viewH = wh - 30 - 8;
        switchCat.to(1f, 12f, dt);
        float ca = a * switchCat.v;
        List<Module> ms = ModuleManager.byCategory(selected);

        Draw.text(ctx, tr, selected.title, viewX + 2, wy + 12, 0xFFFFFF, a);
        String cnt = ms.size() + " modules";
        Draw.text(ctx, tr, cnt, viewX + viewW - tr.getWidth(cnt), wy + 12, 0x6A6A76, a);

        if (ms.isEmpty()) {
            String s = "Coming soon";
            Draw.text(ctx, tr, s, viewX + (viewW - tr.getWidth(s)) / 2, viewY + viewH / 2 - 4, 0x6A6A76, ca);
        }

        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
        scroll.to(scrollTarget, 22f, dt);

        float slide = (1f - Draw.ease(switchCat.v)) * 8f;
        float y = viewY - scroll.v + slide;
        boolean mouseInView = mouseX >= viewX && mouseX <= viewX + viewW && mouseY >= viewY && mouseY <= viewY + viewH;

        ctx.enableScissor(viewX - 2, viewY, viewX + viewW + 2, viewY + viewH);
        for (Module m : ms) {
            m.toggleAnim.to(m.isEnabled() ? 1f : 0f, 14f, dt);
            m.expandAnim.to(m.expanded ? 1f : 0f, 14f, dt);
            int ch = 24 + Math.round(m.expandAnim.v * settingsHeight(m));
            int cy = Math.round(y);
            m.uiX = viewX; m.uiY = cy; m.uiW = viewW;
            boolean hov = mouseInView && mouseY >= cy && mouseY < cy + 24;
            m.hoverAnim.to(hov ? 1f : 0f, 16f, dt);
            if (cy + ch >= viewY && cy <= viewY + viewH) drawCard(ctx, tr, m, ch, ca, acc, dt);
            y += ch + 4;
        }
        ctx.disableScissor();

        float contentH = (y - 4) - (viewY - scroll.v + slide);
        maxScroll = Math.max(0f, contentH - viewH);
        if (maxScroll > 0f) { // полоска прокрутки
            int bh = Math.max(14, Math.round(viewH * viewH / contentH));
            int by = viewY + Math.round((viewH - bh) * (scroll.v / maxScroll));
            Draw.rrect(ctx, viewX + viewW + 3, by, 2, bh, 1, Draw.argb(acc, 0.6f * ca));
        }
    }

    private int settingsHeight(Module m) {
        if (m.settings.isEmpty()) return 0;
        int h = 8;
        for (Setting s : m.settings) h += (s instanceof NumberSetting) ? 26 : 18;
        return h;
    }

    private void drawCard(DrawContext ctx, TextRenderer tr, Module m, int ch, float ca, int acc, float dt) {
        int cx = m.uiX, cy = m.uiY, cw = m.uiW;
        float tg = m.toggleAnim.v;

        Draw.rrect(ctx, cx, cy, cw, ch, 5, Draw.argb(Draw.mix(0x1A1A21, 0x24242E, m.hoverAnim.v), ca));
        if (tg > 0.02f) Draw.rrect(ctx, cx + 3, cy + 6, 2, 12, 1, Draw.argb(acc, ca * tg));
        Draw.text(ctx, tr, m.name, cx + 10, cy + 8, Draw.mix(0x9696A2, 0xFFFFFF, tg), ca);

        // переключатель
        int sx = cx + cw - 30, sy = cy + 7;
        Draw.rrect(ctx, sx, sy, 22, 10, 5, Draw.argb(Draw.mix(0x33333D, acc, tg), ca));
        Draw.rrect(ctx, sx + 1 + Math.round(tg * 12), sy + 1, 8, 8, 4, Draw.argb(0xFFFFFF, ca));

        // три точки = есть настройки
        if (!m.settings.isEmpty()) {
            int dc = Draw.mix(0x6A6A76, acc, m.expandAnim.v);
            for (int i = 0; i < 3; i++) ctx.fill(sx - 14 + i * 4, cy + 11, sx - 12 + i * 4, cy + 13, Draw.argb(dc, ca));
        }

        if (m.expandAnim.v > 0.02f) {
            ctx.enableScissor(cx, cy, cx + cw, cy + ch);
            float ea = ca * m.expandAnim.v;
            ctx.fill(cx + 8, cy + 24, cx + cw - 8, cy + 25, Draw.argb(0xFFFFFF, 0.07f * ea));
            int ry = cy + 28;
            for (Setting s : m.settings) {
                if (s instanceof BoolSetting b) {
                    b.ux = cx; b.uy = ry; b.uw = cw; b.uh = 18;
                    b.anim.to(b.get() ? 1f : 0f, 16f, dt);
                    Draw.text(ctx, tr, b.name, cx + 10, ry + 5, 0xB4B4C0, ea);
                    int mx = cx + cw - 26, my = ry + 4;
                    Draw.rrect(ctx, mx, my, 18, 9, 4, Draw.argb(Draw.mix(0x33333D, acc, b.anim.v), ea));
                    Draw.rrect(ctx, mx + 1 + Math.round(b.anim.v * 9), my + 1, 7, 7, 3, Draw.argb(0xFFFFFF, ea));
                    ry += 18;
                } else if (s instanceof NumberSetting n) {
                    n.ux = cx + 10; n.uy = ry; n.uw = cw - 20; n.uh = 26;
                    n.anim.to(n.frac(), 22f, dt);
                    String vs = n.step >= 1 ? String.valueOf((int) Math.round(n.get()))
                            : String.format(Locale.ROOT, "%.1f", n.get());
                    Draw.text(ctx, tr, n.name, cx + 10, ry + 2, 0xB4B4C0, ea);
                    Draw.text(ctx, tr, vs, cx + cw - 10 - tr.getWidth(vs), ry + 2, acc, ea);
                    int fw = Math.round(n.anim.v * n.uw);
                    Draw.rrect(ctx, n.ux, ry + 16, n.uw, 3, 1, Draw.argb(0x2C2C36, ea));
                    if (fw > 0) Draw.rrect(ctx, n.ux, ry + 16, fw, 3, 1, Draw.argb(acc, ea));
                    Draw.rrect(ctx, n.ux + fw - 3, ry + 14, 7, 7, 3, Draw.argb(0xFFFFFF, ea));
                    ry += 26;
                }
            }
            ctx.disableScissor();
        }
    }

    // ------------------------------------------------------------ ввод
    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private boolean inView(double mx, double my) { return in(mx, my, viewX, viewY, viewW, viewH); }

    private void select(Category c) {
        if (c == selected) return;
        selected = c;
        switchCat.v = 0f;
        scrollTarget = 0f;
        scroll.v = 0f;
    }

    private void setSlider(NumberSetting s, double mx) {
        double f = Math.max(0.0, Math.min(1.0, (mx - s.ux) / (double) s.uw));
        double raw = s.min + f * (s.max - s.min);
        s.set(Math.round(raw / s.step) * s.step);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (open.v < 0.9f || closing) return true;
        if (!in(mx, my, wx, wy, ww, wh)) { close(); return true; }

        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            if (in(mx, my, wx + 8, wy + 36 + i * 24, SW - 12, 20)) { select(cats[i]); return true; }
        }
        if (inView(mx, my)) {
            for (Module m : ModuleManager.byCategory(selected)) {
                if (m.expandAnim.v < 0.6f) continue;
                for (Setting s : m.settings) {
                    if (s instanceof NumberSetting n && in(mx, my, n.ux - 4, n.uy + 10, n.uw + 8, 14)) {
                        dragSlider = n;
                        setSlider(n, mx);
                        return true;
                    }
                }
            }
            pressing = true;
            px = mx; py = my; moved = 0;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragSlider != null) { setSlider(dragSlider, mx); return true; }
        if (pressing) {
            moved += Math.abs(dx) + Math.abs(dy);
            scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) dy));
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragSlider != null) { dragSlider = null; return true; }
        if (pressing) {
            pressing = false;
            if (moved < 6) tap(px, py);
        }
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) v * 22f));
        return true;
    }

    private void tap(double mx, double my) {
        for (Module m : ModuleManager.byCategory(selected)) {
            if (in(mx, my, m.uiX, m.uiY, m.uiW, 24)) {
                boolean onDots = !m.settings.isEmpty() && mx >= m.uiX + m.uiW - 52 && mx < m.uiX + m.uiW - 32;
                if (onDots) m.expanded = !m.expanded; else m.toggle();
                return;
            }
            if (m.expandAnim.v > 0.6f) {
                for (Setting s : m.settings) {
                    if (s instanceof BoolSetting b && in(mx, my, b.ux, b.uy, b.uw, b.uh)) { b.toggle(); return; }
                }
            }
        }
    }
}
