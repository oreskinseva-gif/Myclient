package com.ezuk.client.gui;

import com.ezuk.client.Category;
import com.ezuk.client.Module;
import com.ezuk.client.ModuleManager;
import com.ezuk.client.setting.BoolSetting;
import com.ezuk.client.setting.ModeSetting;
import com.ezuk.client.setting.NumberSetting;
import com.ezuk.client.setting.Setting;
import com.ezuk.client.util.Anim;
import com.ezuk.client.util.Draw;
import com.ezuk.client.util.Theme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ClickGuiScreen extends Screen {
    private static Category selected = Category.COMBAT;
    private static final int HH = 22, GAP = 5, BTN_H = 20;

    private static class Chip { ModeSetting mo; int idx, x, y, w, h; }

    private final Anim open = new Anim(0), switchCat = new Anim(1), scroll = new Anim(0), searchAnim = new Anim(0);
    private final Anim[] catSel = new Anim[Category.values().length];
    private final int[] btnY = new int[Category.values().length];
    private final List<Chip> chips = new ArrayList<>();
    private final StringBuilder query = new StringBuilder();
    private List<Module> visible = new ArrayList<>();

    private boolean closing, searching;
    private float scrollTarget, maxScroll;
    private long last = System.nanoTime();
    private int wx, wy, ww, wh, sbw, btnX, btnW, cx0, cw, gy, gh;
    private int pressArea;
    private double pressX, pressY, moved;
    private NumberSetting dragSlider;

    public ClickGuiScreen() {
        super(Text.literal("Ezuk"));
        for (int i = 0; i < catSel.length; i++) catSel[i] = new Anim(Category.values()[i] == selected ? 1f : 0f);
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void close() { closing = true; }
    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) {}

    // ------------------------------------------------------------ клавиатура
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (searching) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) { stopSearch(); return true; }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (query.length() > 0) query.setLength(query.length() - 1);
                return true;
            }
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT && !searching) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searching && chr >= 32 && query.length() < 24) {
            query.append(chr);
            scrollTarget = 0f;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    private void stopSearch() { searching = false; query.setLength(0); }

    // ------------------------------------------------------------ раскладка настроек
    private static int modeRows(TextRenderer tr, ModeSetting mo, int innerW) {
        int rows = 1, cx = 0;
        for (String m : mo.modes) {
            int w = tr.getWidth(m) + 10;
            if (cx + w > innerW && cx > 0) { rows++; cx = 0; }
            cx += w + 4;
        }
        return rows;
    }

    private static int settingH(TextRenderer tr, Setting s, int w) {
        if (s instanceof NumberSetting) return 26;
        if (s instanceof ModeSetting mo) return 13 + modeRows(tr, mo, w - 16) * 17 + 3;
        return 18;
    }

    private static int settingsHeight(TextRenderer tr, Module m, int w) {
        if (m.settings.isEmpty()) return 0;
        int h = 8;
        for (Setting s : m.settings) h += settingH(tr, s, w);
        return h;
    }

    // ------------------------------------------------------------ рендер
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;

        open.to(closing ? 0f : 1f, 12f, dt);
        if (closing && open.v < 0.03f) { client.setScreen(null); return; }
        float a = Draw.ease(open.v);

        TextRenderer tr = client.textRenderer;
        int acc = Theme.accent();
        ctx.fill(0, 0, width, height, Draw.argb(0x000000, 0.55f * a));

        ww = Math.min(520, width - 12);
        wh = Math.min(300, height - 12);
        wx = (width - ww) / 2;
        wy = (height - wh) / 2 + Math.round((1f - a) * 16f);

        Draw.rrect(ctx, wx - 1, wy - 1, ww + 2, wh + 2, 10, Draw.argb(acc, 0.22f * a));
        Draw.rrect(ctx, wx, wy, ww, wh, 9, Draw.argb(0x0D0D11, a));

        sbw = Math.max(96, Math.min(124, ww / 4));
        Draw.rrect(ctx, wx + 4, wy + 4, sbw, wh - 8, 7, Draw.argb(0x09090C, a));
        drawSidebar(ctx, tr, a, acc, dt);

        cx0 = wx + sbw + 12;
        cw = ww - sbw - 20;
        drawHeader(ctx, tr, a, acc, dt);

        gy = wy + 34;
        gh = wh - 34 - 8;
        switchCat.to(1f, 12f, dt);
        drawGrid(ctx, tr, mouseX, mouseY, a * switchCat.v, acc, dt);
    }

    private void drawSidebar(DrawContext ctx, TextRenderer tr, float a, int acc, float dt) {
        Category[] cats = Category.values();
        btnX = wx + 10;
        btnW = sbw - 12;
        boolean labels = wh >= 222, profile = wh >= 250;

        int y = wy + 10;
        Draw.logoE(ctx, wx + 4 + (sbw - 18) / 2, y, 18, acc, a);
        y += 26;

        String lastSection = "";
        for (int i = 0; i < cats.length; i++) {
            Category c = cats[i];
            if (labels && !c.section.equals(lastSection)) {
                Draw.text(ctx, tr, c.section, wx + 4 + (sbw - tr.getWidth(c.section)) / 2, y, 0x6A6A76, a);
                y += 11;
            }
            lastSection = c.section;
            btnY[i] = y;

            catSel[i].to(c == selected ? 1f : 0f, 14f, dt);
            float s = catSel[i].v;
            Draw.rrect(ctx, btnX - 1, y - 1, btnW + 2, BTN_H + 2, 6,
                    Draw.argb(Draw.mix(0x2C2C34, acc, s * 0.8f), a * (0.55f + 0.45f * s)));
            Draw.rrect(ctx, btnX, y, btnW, BTN_H, 5, Draw.argb(Draw.mix(0x15151A, 0x1E1E26, s), a));
            Draw.rrect(ctx, btnX + 6, y + 5, 10, 10, 3, Draw.argb(Draw.mix(0x55555F, acc, s), a));
            Draw.rrect(ctx, btnX + 8, y + 7, 6, 6, 2, Draw.argb(Draw.mix(0x15151A, 0x1E1E26, s), a));
            Draw.text(ctx, tr, c.title, btnX + 22, y + 6, Draw.mix(0x9696A2, 0xFFFFFF, s), a);
            y += BTN_H + 3;
        }

        if (profile) {
            int py = wy + wh - 8 - 30;
            String name = client.getSession().getUsername();
            Draw.rrect(ctx, btnX - 1, py - 1, btnW + 2, 30, 6, Draw.argb(0x2C2C34, a * 0.8f));
            Draw.rrect(ctx, btnX, py, btnW, 28, 5, Draw.argb(0x121217, a));
            Draw.rrect(ctx, btnX + 4, py + 5, 18, 18, 3, Draw.argb(Draw.mix(0x2A2A33, acc, 0.4f), a));
            String ini = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT);
            Draw.text(ctx, tr, ini, btnX + 4 + (18 - tr.getWidth(ini)) / 2, py + 10, 0xFFFFFF, a);
            Draw.text(ctx, tr, tr.trimToWidth("User: " + name, btnW - 30), btnX + 27, py + 6, 0xD0D0DA, a);
            Draw.text(ctx, tr, "Role: USER", btnX + 27, py + 16, acc, a);
        }
    }

    private void drawHeader(DrawContext ctx, TextRenderer tr, float a, int acc, float dt) {
        searchAnim.to(searching ? 1f : 0f, 14f, dt);
        int sw = 18 + Math.round(searchAnim.v * (cw - 18));
        int y = wy + 8;
        Draw.rrect(ctx, cx0 - 1, y - 1, sw + 2, 20, 6, Draw.argb(Draw.mix(0x2C2C34, acc, searchAnim.v * 0.7f), a * 0.9f));
        Draw.rrect(ctx, cx0, y, sw, 18, 5, Draw.argb(0x121217, a));
        int ic = Draw.mix(0x9696A2, acc, searchAnim.v);
        Draw.rrect(ctx, cx0 + 4, y + 3, 9, 9, 4, Draw.argb(ic, a));
        Draw.rrect(ctx, cx0 + 6, y + 5, 5, 5, 2, Draw.argb(0x121217, a));
        ctx.fill(cx0 + 12, y + 11, cx0 + 15, y + 13, Draw.argb(ic, a));

        if (searchAnim.v > 0.5f) {
            boolean caret = (System.currentTimeMillis() / 500) % 2 == 0;
            String q = query.length() == 0 ? "Search..." : query.toString();
            int col = query.length() == 0 ? 0x6A6A76 : 0xFFFFFF;
            Draw.text(ctx, tr, tr.trimToWidth(q, cw - 34), cx0 + 22, y + 5, col, a * searchAnim.v);
            if (caret && query.length() > 0) {
                int cx = cx0 + 22 + tr.getWidth(tr.trimToWidth(q, cw - 34));
                ctx.fill(cx + 1, y + 4, cx + 2, y + 13, Draw.argb(acc, a));
            }
        } else {
            Draw.text(ctx, tr, selected.title, cx0 + 24, y + 5, 0xFFFFFF, a * (1f - searchAnim.v));
        }
    }

    private void refreshVisible() {
        if (searching && query.length() > 0) {
            String q = query.toString().toLowerCase(Locale.ROOT);
            List<Module> out = new ArrayList<>();
            for (Module m : ModuleManager.modules) if (m.name.toLowerCase(Locale.ROOT).contains(q)) out.add(m);
            visible = out;
        } else {
            visible = ModuleManager.byCategory(selected);
        }
    }

    private void drawGrid(DrawContext ctx, TextRenderer tr, int mouseX, int mouseY, float ca, int acc, float dt) {
        refreshVisible();
        chips.clear();

        int cols = cw >= 330 ? 3 : 2;
        int colW = (cw - GAP * (cols - 1)) / cols;
        float[] colY = new float[cols];

        for (int i = 0; i < visible.size(); i++) {
            Module m = visible.get(i);
            m.toggleAnim.to(m.isEnabled() ? 1f : 0f, 14f, dt);
            m.expandAnim.to(m.expanded && !m.settings.isEmpty() ? 1f : 0f, 14f, dt);
            int c = i % cols;
            int h = HH;
            if (!m.settings.isEmpty()) h += Math.round(m.expandAnim.v * (settingsHeight(tr, m, colW) + 6));
            m.uiX = cx0 + c * (colW + GAP);
            m.uiW = colW;
            m.uiH = h;
            m.uiY = Math.round(colY[c]); // относительная позиция, сдвиг добавим ниже
            colY[c] += h + GAP;
        }
        float contentH = 0;
        for (float v : colY) contentH = Math.max(contentH, v - GAP);
        maxScroll = Math.max(0f, contentH - gh);
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
        scroll.to(scrollTarget, 22f, dt);
        float slide = (1f - Draw.ease(switchCat.v)) * 8f;

        if (visible.isEmpty()) {
            String s = searching ? "Nothing found" : "Coming soon";
            Draw.text(ctx, tr, s, cx0 + (cw - tr.getWidth(s)) / 2, gy + gh / 2 - 4, 0x6A6A76, ca);
        }

        ctx.enableScissor(cx0 - 2, gy, cx0 + cw + 2, gy + gh);
        for (Module m : visible) {
            m.uiY = Math.round(gy + m.uiY - scroll.v + slide);
            boolean hov = mouseX >= m.uiX && mouseX < m.uiX + m.uiW && mouseY >= m.uiY && mouseY < m.uiY + HH
                    && mouseY >= gy && mouseY < gy + gh;
            m.hoverAnim.to(hov ? 1f : 0f, 16f, dt);
            if (m.uiY + m.uiH >= gy && m.uiY <= gy + gh) drawCard(ctx, tr, m, ca, acc, dt);
        }
        ctx.disableScissor();

        if (maxScroll > 0f) {
            int sbh = Math.max(14, Math.round(gh * gh / contentH));
            int sby = gy + Math.round((gh - sbh) * (scroll.v / maxScroll));
            Draw.rrect(ctx, cx0 + cw + 1, sby, 2, sbh, 1, Draw.argb(acc, 0.6f * ca));
        }
    }

    private void drawCard(DrawContext ctx, TextRenderer tr, Module m, float ca, int acc, float dt) {
        int x = m.uiX, y = m.uiY, w = m.uiW, h = m.uiH;
        float tg = m.toggleAnim.v, ex = m.expandAnim.v;

        int base = Draw.mix(Draw.mix(0x141418, 0x1B1B21, m.hoverAnim.v), 0x2A2A33, 0.55f * tg);
        Draw.rrect(ctx, x, y, w, h, 6, Draw.argb(base, ca));
        Draw.rrect(ctx, x + 7, y + 9, 5, 5, 2, Draw.argb(Draw.mix(0xFF5A5A, acc, tg), ca));
        Draw.text(ctx, tr, tr.trimToWidth(m.name, w - 42), x + 17, y + 7, Draw.mix(0xA0A0AC, 0xFFFFFF, tg), ca);

        if (!m.settings.isEmpty()) {
            int gx = x + w - 16, gyy = y + 7, ic = Draw.mix(0x77778A, acc, ex);
            Draw.rrect(ctx, gx, gyy, 9, 9, 4, Draw.argb(ic, ca));
            Draw.rrect(ctx, gx + 1, gyy + 1, 7, 7, 3, Draw.argb(base, ca));
            ctx.fill(gx + 2, gyy + 4, gx + 7, gyy + 5, Draw.argb(ic, ca));
            ctx.fill(gx + 4, gyy + 2, gx + 5, gyy + 7, Draw.argb(ic, ca * (1f - ex)));
        }

        if (ex > 0.02f) {
            ctx.enableScissor(x, Math.max(y, gy), x + w, Math.min(y + h, gy + gh));
            float ea = ca * ex;
            int ry = y + HH + 4;
            for (Setting s : m.settings) {
                int sh = settingH(tr, s, w);
                s.ux = x; s.uy = ry; s.uw = w; s.uh = sh;
                if (s instanceof BoolSetting b) {
                    b.anim.to(b.get() ? 1f : 0f, 16f, dt);
                    Draw.text(ctx, tr, tr.trimToWidth(b.name, w - 40), x + 8, ry + 5, 0xB4B4C0, ea);
                    int sx = x + w - 28, sy = ry + 4;
                    Draw.rrect(ctx, sx, sy, 18, 9, 4, Draw.argb(Draw.mix(0x33333D, acc, b.anim.v), ea));
                    Draw.rrect(ctx, sx + 1 + Math.round(b.anim.v * 9), sy + 1, 7, 7, 3, Draw.argb(0xFFFFFF, ea));
                } else if (s instanceof NumberSetting n) {
                    n.ux = x + 8; n.uw = w - 16;
                    n.anim.to(n.frac(), 22f, dt);
                    String vs = n.step >= 1 ? String.valueOf((int) Math.round(n.get()))
                            : String.format(Locale.ROOT, "%.2f", n.get());
                    Draw.text(ctx, tr, n.name, x + 8, ry + 1, 0xB4B4C0, ea);
                    Draw.text(ctx, tr, vs, x + w - 8 - tr.getWidth(vs), ry + 1, acc, ea);
                    int fw = Math.round(n.anim.v * n.uw);
                    Draw.rrect(ctx, n.ux, ry + 15, n.uw, 3, 1, Draw.argb(0x2C2C36, ea));
                    if (fw > 0) Draw.rrect(ctx, n.ux, ry + 15, fw, 3, 1, Draw.argb(acc, ea));
                    Draw.rrect(ctx, n.ux + fw - 3, ry + 13, 7, 7, 3, Draw.argb(0xFFFFFF, ea));
                } else if (s instanceof ModeSetting mo) {
                    Draw.text(ctx, tr, mo.name, x + 8, ry + 1, 0xB4B4C0, ea);
                    int cxp = x + 8, cyp = ry + 12;
                    for (int i = 0; i < mo.modes.length; i++) {
                        int tw = tr.getWidth(mo.modes[i]) + 10;
                        if (cxp + tw > x + w - 8 && cxp > x + 8) { cxp = x + 8; cyp += 17; }
                        boolean sel = i == mo.index();
                        Draw.rrect(ctx, cxp, cyp, tw, 15, 4, Draw.argb(sel ? Draw.mix(0x24242D, acc, 0.35f) : 0x1B1B22, ea));
                        Draw.text(ctx, tr, mo.modes[i], cxp + 5, cyp + 4, sel ? 0xFFFFFF : 0x9696A2, ea);
                        Chip c = new Chip();
                        c.mo = mo; c.idx = i; c.x = cxp; c.y = cyp; c.w = tw; c.h = 15;
                        chips.add(c);
                        cxp += tw + 4;
                    }
                }
                ry += sh;
            }
            ctx.disableScissor();
        }
    }

    // ------------------------------------------------------------ ввод
    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void select(Category c) {
        stopSearch();
        if (c == selected) return;
        selected = c;
        switchCat.v = 0f;
        scrollTarget = 0f;
        scroll.v = 0f;
    }

    private void setSlider(NumberSetting s, double mx) {
        double f = Math.max(0.0, Math.min(1.0, (mx - s.ux) / (double) s.uw));
        double raw = s.min + f * (s.max - s.min);
        s.set(Math.round(raw / s.step) * s.step);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (open.v < 0.9f || closing) return true;
        if (!in(mx, my, wx, wy, ww, wh)) { close(); return true; }

        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            if (in(mx, my, btnX, btnY[i], btnW, BTN_H)) { select(cats[i]); return true; }
        }

        int sw = 18 + Math.round(searchAnim.v * (cw - 18));
        if (in(mx, my, cx0, wy + 8, sw, 18)) {
            if (!searching) searching = true;
            else if (mx < cx0 + 18) stopSearch();
            return true;
        }

        pressArea = 0;
        if (in(mx, my, cx0, gy, cw, gh)) {
            for (Module m : visible) {
                if (m.expandAnim.v < 0.6f) continue;
                for (Setting s : m.settings) {
                    if (s instanceof NumberSetting n && in(mx, my, n.ux - 4, n.uy + 9, n.uw + 8, 14)
                            && in(mx, my, m.uiX, m.uiY, m.uiW, m.uiH)) {
                        dragSlider = n;
                        setSlider(n, mx);
                        return true;
                    }
                }
            }
            pressArea = 1;
            pressX = mx; pressY = my; moved = 0;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragSlider != null) { setSlider(dragSlider, mx); return true; }
        if (pressArea == 1) {
            moved += Math.abs(dx) + Math.abs(dy);
            scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) dy));
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragSlider != null) { dragSlider = null; return true; }
        int area = pressArea;
        pressArea = 0;
        if (area == 1 && moved < 6) tap(pressX, pressY);
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) v * 22f));
        return true;
    }

    private void tap(double mx, double my) {
        for (Module m : visible) {
            if (!in(mx, my, m.uiX, m.uiY, m.uiW, m.uiH)) continue;
            if (my < m.uiY + HH) {
                boolean gear = !m.settings.isEmpty() && mx >= m.uiX + m.uiW - 24;
                if (gear) m.expanded = !m.expanded; else m.toggle();
                return;
            }
            if (m.expandAnim.v > 0.6f) {
                for (Chip c : chips) {
                    if (in(mx, my, c.x, c.y, c.w, c.h)) { c.mo.set(c.idx); return; }
                }
                for (Setting s : m.settings) {
                    if (s instanceof BoolSetting b && in(mx, my, b.ux, b.uy, b.uw, b.uh)) { b.toggle(); return; }
                }
            }
            return;
        }
    }
}
