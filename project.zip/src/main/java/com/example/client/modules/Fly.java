package com.example.client.modules;

import com.example.client.Module;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class Fly extends Module {
    public Fly() { super("Fly", GLFW.GLFW_KEY_G); }

    @Override
    public void onTick(MinecraftClient mc) {
        mc.player.getAbilities().allowFlying = true;
        mc.player.getAbilities().flying = true;
    }

    @Override
    public void onDisable(MinecraftClient mc) {
        if (mc.player == null || mc.player.isCreative() || mc.player.isSpectator()) return;
        mc.player.getAbilities().allowFlying = false;
        mc.player.getAbilities().flying = false;
    }
}
