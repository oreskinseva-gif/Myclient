package com.example.client.modules;

import com.example.client.Module;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class Sprint extends Module {
    public Sprint() { super("Sprint", GLFW.GLFW_KEY_R); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.options.forwardKey.isPressed() && !mc.player.horizontalCollision
                && mc.player.getHungerManager().getFoodLevel() > 6) {
            mc.player.setSprinting(true);
        }
    }
}
