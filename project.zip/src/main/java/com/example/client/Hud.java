package com.example.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class Hud {
    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;
        int y = 4;
        ctx.drawTextWithShadow(mc.textRenderer, MyClient.NAME, 4, y, 0xFF55FFFF);
        y += 12;
        for (Module m : ModuleManager.modules) {
            if (!m.isEnabled()) continue;
            ctx.drawTextWithShadow(mc.textRenderer, m.name, 4, y, 0xFFFFFFFF);
            y += 10;
        }
    }
}
