package com.example.client;

import com.example.client.modules.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> modules = new ArrayList<>();

    public static void init() {
        modules.add(new Sprint());
        modules.add(new FullBright());
        modules.add(new Fly());
    }

    private static boolean menuWasDown;

    public static void handleKeys(MinecraftClient mc) {
        if (mc.currentScreen != null) return; // не реагируем в меню/чате
        long window = mc.getWindow().getHandle();
        // Правый Shift открывает меню (на телефоне можно повесить на экранную кнопку в FCL)
        boolean menuDown = InputUtil.isKeyPressed(window, org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT);
        if (menuDown && !menuWasDown) mc.setScreen(new ModuleScreen());
        menuWasDown = menuDown;
        for (Module m : modules) {
            boolean down = InputUtil.isKeyPressed(window, m.key);
            if (down && !m.wasDown) m.toggle();
            m.wasDown = down;
        }
    }
}
