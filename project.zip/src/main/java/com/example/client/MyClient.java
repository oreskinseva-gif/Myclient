package com.example.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

public class MyClient implements ClientModInitializer {
    public static final String NAME = "MyClient";

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null || mc.world == null) return;
            ModuleManager.handleKeys(mc);
            for (Module m : ModuleManager.modules) {
                if (m.isEnabled()) m.onTick(mc);
            }
        });
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> Hud.render(ctx));
    }
}
