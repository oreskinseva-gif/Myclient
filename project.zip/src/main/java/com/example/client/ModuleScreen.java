package com.example.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ModuleScreen extends Screen {
    public ModuleScreen() {
        super(Text.literal(MyClient.NAME));
    }

    @Override
    protected void init() {
        int w = 140, h = 20, x = width / 2 - w / 2;
        int y = height / 2 - ModuleManager.modules.size() * 12;
        for (Module m : ModuleManager.modules) {
            ButtonWidget[] ref = new ButtonWidget[1];
            ref[0] = ButtonWidget.builder(label(m), b -> {
                m.toggle();
                b.setMessage(label(m));
            }).dimensions(x, y, w, h).build();
            addDrawableChild(ref[0]);
            y += 24;
        }
    }

    private Text label(Module m) {
        return Text.literal(m.name + ": " + (m.isEnabled() ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 20, 0xFF55FFFF);
    }

    @Override
    public boolean shouldPause() { return false; }
}
