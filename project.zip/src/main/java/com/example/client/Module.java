package com.example.client;

import net.minecraft.client.MinecraftClient;

public abstract class Module {
    public final String name;
    public final int key; // GLFW key code
    boolean wasDown;
    private boolean enabled;

    protected Module(String name, int key) {
        this.name = name;
        this.key = key;
    }

    public boolean isEnabled() { return enabled; }

    public void toggle() {
        enabled = !enabled;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (enabled) onEnable(mc); else onDisable(mc);
    }

    public void onEnable(MinecraftClient mc) {}
    public void onDisable(MinecraftClient mc) {}
    public void onTick(MinecraftClient mc) {}
}
