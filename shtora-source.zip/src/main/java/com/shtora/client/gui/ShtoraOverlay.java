package com.shtora.client.gui;

import com.shtora.client.util.Draw;
import com.shtora.client.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Overlay;

/**
 * Загрузочный экран Shtora: тёмный фон, светящийся контур буквы S и полоса загрузки.
 * Контур показан уже здесь — частицы, которые его заполнят, летят на главном экране.
 */
public class ShtoraOverlay extends Overlay {
    private final Overlay inner;
    private final long start = System.currentTimeMillis();

    public ShtoraOverlay(Overlay inner) { this.inner = inner; }

    @Override
    public boolean pausesGame() { return inner.pausesGame(); }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        inner.render(ctx, mouseX, mouseY, delta); // идёт настоящая загрузка ресурсов

        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        float t = (System.currentTimeMillis() - start) / 1000f;
        int acc = Theme.accent();

        // фон
        Draw.vgrad(ctx, 0, 0, sw, sh, Theme.BG_TOP, Theme.BG_BOTTOM, 1f);
        // оранжевое свечение у нижней кромки
        for (int k = 5; k >= 1; k--) {
            ctx.fill(0, sh - k * 14, sw, sh - (k - 1) * 14, Draw.argb(acc, 0.022f * k));
        }

        // буква S: контур со свечением + заливка по мере загрузки
        int cell = Math.max(4, Math.min(10, Math.min(sw, sh) / 26));
        int gw = Draw.GLYPH_W * cell, gh = Draw.GLYPH_H * cell;
        int gx = (sw - gw) / 2, gy = Math.round(sh * 0.42f) - gh / 2;

        float pulse = 0.55f + 0.45f * (float) Math.sin(t * 2.2);
        Draw.logoGlow(ctx, gx, gy, cell, acc, 0.45f + 0.35f * pulse);
        Draw.logoOutline(ctx, gx, gy, cell, acc, 0.75f + 0.25f * pulse);

        float p = Math.min(0.97f, 1f - (float) Math.exp(-t / 4.5f));
        if (p > 0.02f) Draw.logoS(ctx, gx, gy, cell, Draw.mix(acc, 0xFFFFFF, 0.25f), 0.12f * p);

        // подпись под буквой
        String brand = "SHTORA", rest = " CLIENT";
        int by = gy + gh + Math.max(12, cell * 2);
        int bw = Draw.w(tr, brand) + Draw.w(tr, rest);
        int bx = (sw - bw) / 2;
        Draw.text(ctx, tr, brand, bx, by, acc, 1f);
        Draw.text(ctx, tr, rest, bx + Draw.w(tr, brand), by, 0xFFFFFF, 0.85f);

        // полоса загрузки
        int pw = Math.min(220, Math.max(80, sw / 2)), px = (sw - pw) / 2, py = Math.round(sh * 0.84f);
        ctx.fill(px, py, px + pw, py + 2, Draw.argb(0xFFFFFF, 0.10f));
        ctx.fill(px, py, px + Math.max(2, Math.round(pw * p)), py + 2, Draw.argb(acc, 1f));
        String st = Math.round(p * 100) + "%";
        Draw.text(ctx, tr, st, (sw - Draw.w(tr, st)) / 2, py + 8, Theme.TEXT_DIM, 1f);
    }
}
