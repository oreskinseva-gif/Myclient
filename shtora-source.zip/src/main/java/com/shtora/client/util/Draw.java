package com.shtora.client.util;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class Draw {
    private Draw() {}

    public static float clamp(float x) { return Math.max(0f, Math.min(1f, x)); }

    public static float ease(float x) { float t = 1f - clamp(x); return 1f - t * t * t; }

    public static int argb(int rgb, float a) {
        return ((int) (clamp(a) * 255f) << 24) | (rgb & 0xFFFFFF);
    }

    public static int mix(int c1, int c2, float t) {
        t = clamp(t);
        int r = (int) (((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
        int g = (int) (((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
        int b = (int) ((c1 & 255) * (1 - t) + (c2 & 255) * t);
        return (r << 16) | (g << 8) | b;
    }

    /** Скруглённый прямоугольник (построчно). */
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }

    private static int inset(int r, int i) {
        double dy = r - i - 0.5;
        return (int) Math.round(r - Math.sqrt(Math.max(0, r * r - dy * dy)));
    }

    /** Тонкая (1px) скруглённая рамка. */
    public static void outline(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 2 || h <= 2) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        c.fill(x + r, y, x + w - r, y + 1, color);
        c.fill(x + r, y + h - 1, x + w - r, y + h, color);
        c.fill(x, y + r, x + 1, y + h - r, color);
        c.fill(x + w - 1, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            int o = inset(r, i);
            int prev = i == 0 ? r : inset(r, i - 1);
            int span = Math.max(1, prev - o);
            c.fill(x + o, y + i, x + o + span, y + i + 1, color);
            c.fill(x + w - o - span, y + i, x + w - o, y + i + 1, color);
            c.fill(x + o, y + h - i - 1, x + o + span, y + h - i, color);
            c.fill(x + w - o - span, y + h - i - 1, x + w - o, y + h - i, color);
        }
    }

    /** Прямоугольная рамка по двум углам. */
    public static void box(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        c.fill(x1, y1, x2, y1 + 1, color);
        c.fill(x1, y2 - 1, x2, y2, color);
        c.fill(x1, y1, x1 + 1, y2, color);
        c.fill(x2 - 1, y1, x2, y2, color);
    }

    /** Линия из коротких прямоугольников (одна заливка на строку или столбец). */
    public static void line(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        int dx = x2 - x1, dy = y2 - y1;
        if (Math.abs(dy) >= Math.abs(dx)) {
            int sy = dy >= 0 ? 1 : -1;
            for (int y = y1; y != y2 + sy; y += sy) {
                float t = dy == 0 ? 0f : (float) (y - y1) / dy;
                float tn = dy == 0 ? 0f : (float) (y + sy - y1) / dy;
                int xa = Math.round(x1 + dx * t), xb = Math.round(x1 + dx * Math.min(1f, Math.max(0f, tn)));
                c.fill(Math.min(xa, xb), Math.min(y, y + 1), Math.max(xa, xb) + 1, Math.min(y, y + 1) + 1, color);
            }
        } else {
            int sx = dx >= 0 ? 1 : -1;
            for (int x = x1; x != x2 + sx; x += sx) {
                float t = (float) (x - x1) / dx;
                float tn = (float) (x + sx - x1) / dx;
                int ya = Math.round(y1 + dy * t), yb = Math.round(y1 + dy * Math.min(1f, Math.max(0f, tn)));
                c.fill(Math.min(x, x + 1), Math.min(ya, yb), Math.min(x, x + 1) + 1, Math.max(ya, yb) + 1, color);
            }
        }
    }

    /** Шрифт клиента (Carlito), подключён через assets/shtora/font/ui.json. */
    public static final Identifier FONT = Identifier.of("shtora", "ui");

    public static Text styled(String s) {
        return Text.literal(s).setStyle(Style.EMPTY.withFont(FONT));
    }

    public static int w(TextRenderer tr, String s) { return tr.getWidth(styled(s)); }

    public static String trim(TextRenderer tr, String s, int max) {
        if (w(tr, s) <= max) return s;
        String t = s;
        while (!t.isEmpty() && w(tr, t) > max) t = t.substring(0, t.length() - 1);
        return t;
    }

    public static void text(DrawContext c, TextRenderer tr, String s, int x, int y, int rgb, float a) {
        if (a < 0.06f) return; // слишком прозрачный текст в майне рисуется непрозрачным
        c.drawText(tr, styled(s), x, y, argb(rgb, a), false);
    }

    // ---------------------------------------------------------------- буква S

    /** Растровая маска буквы S: 11 клеток в ширину, 17 в высоту. X — закрашено. */
    public static final String[] GLYPH_S = {
            "..XXXXXXX..",
            ".XXXXXXXXX.",
            "XXXX...XXXX",
            "XXX.....XXX",
            "XXX......XX",
            "XXX........",
            ".XXX.......",
            "..XXXX.....",
            "...XXXX....",
            "....XXXX...",
            ".....XXXX..",
            ".......XXX.",
            "........XXX",
            "........XXX",
            "XXX....XXXX",
            ".XXXXXXXXX.",
            "..XXXXXXX.."
    };
    public static final int GLYPH_W = 11, GLYPH_H = 17;

    public static boolean glyphOn(int col, int row) {
        if (col < 0 || col >= GLYPH_W || row < 0 || row >= GLYPH_H) return false;
        return GLYPH_S[row].charAt(col) == 'X';
    }

    /** Клетка на границе фигуры (у соседа пусто) — это и есть контур. */
    public static boolean glyphEdge(int col, int row) {
        if (!glyphOn(col, row)) return false;
        return !glyphOn(col - 1, row) || !glyphOn(col + 1, row)
                || !glyphOn(col, row - 1) || !glyphOn(col, row + 1);
    }

    /** Залитая буква S из квадратных клеток. */
    public static void logoS(DrawContext c, int x, int y, int cell, int rgb, float a) {
        int col = argb(rgb, a);
        for (int r = 0; r < GLYPH_H; r++)
            for (int i = 0; i < GLYPH_W; i++)
                if (glyphOn(i, r))
                    c.fill(x + i * cell, y + r * cell, x + i * cell + cell, y + r * cell + cell, col);
    }

    /** Только контур буквы S. */
    public static void logoOutline(DrawContext c, int x, int y, int cell, int rgb, float a) {
        int col = argb(rgb, a);
        for (int r = 0; r < GLYPH_H; r++)
            for (int i = 0; i < GLYPH_W; i++)
                if (glyphEdge(i, r))
                    c.fill(x + i * cell, y + r * cell, x + i * cell + cell, y + r * cell + cell, col);
    }

    /** Свечение вокруг контура S: несколько расширенных силуэтов с малой прозрачностью. */
    public static void logoGlow(DrawContext c, int x, int y, int cell, int rgb, float a) {
        for (int k = 3; k >= 1; k--) {
            int pad = k * 2;
            int col = argb(rgb, a * (0.12f / k));
            for (int r = 0; r < GLYPH_H; r++)
                for (int i = 0; i < GLYPH_W; i++)
                    if (glyphEdge(i, r))
                        c.fill(x + i * cell - pad, y + r * cell - pad,
                                x + i * cell + cell + pad, y + r * cell + cell + pad, col);
        }
    }

    /** Вертикальный градиент на всю область. */
    public static void vgrad(DrawContext c, int x, int y, int w, int h, int top, int bottom, float a) {
        if (w <= 0 || h <= 0) return;
        c.fillGradient(x, y, x + w, y + h, argb(top, a), argb(bottom, a));
    }

    public static int hsb(float h, float s, float v) {
        float r, g, b;
        float hh = (h - (float) Math.floor(h)) * 6f;
        int i = (int) hh;
        float f = hh - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        switch (i % 6) {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q;
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }
}
