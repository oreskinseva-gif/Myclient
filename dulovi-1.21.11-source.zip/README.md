# dulovi

Fabric client for Minecraft **1.21.11**.

- Menu & visuals inspired by **Wild** (dark cards, accent, Right Shift)
- Module architecture in the style of **LiquidBounce**

## Build

```bash
./gradlew build
```

Jar appears in `build/libs/dulovi-1.0.0.jar`.

## Controls

- **Right Shift** — open ClickGUI

## Modules included

**Combat:** KillAura, Velocity  
**Movement:** Speed, Fly, Sprint  
**Render:** ESP, Fullbright, Tracers  
**World:** Scaffold  
**Player:** NoFall, AutoTotem  
**Misc:** ClickGUI

## Notes

- ESP / Tracers are stubs (need world-render hooks for full boxes/lines).
- Scaffold / KillAura / Speed / Fly / NoFall / AutoTotem / Fullbright are functional.
- Expand by adding new classes under `module/modules/` and registering them in `ModuleManager`.
