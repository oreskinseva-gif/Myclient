package ru.dulovi.setting;

import java.util.Arrays;
import java.util.List;

public class ModeSetting extends Setting<String> {
    public final List<String> modes;

    public ModeSetting(String name, String defaultValue, String... modes) {
        super(name, defaultValue);
        this.modes = Arrays.asList(modes);
    }

    public void cycle() {
        int idx = modes.indexOf(get());
        set(modes.get((idx + 1) % modes.size()));
    }
}
