package ru.dulovi.gui.components;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import ru.dulovi.module.Module;
import ru.dulovi.util.RenderUtil;
import ru.dulovi.util.Theme;

public class ModuleButton {
    public final Module module;
    public float x, y, width, height;

    public ModuleButton(Module module, float x, float y, float width, float height) {
        this.module = module;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void render(DrawContext ctx, int mx, int my, TextRenderer tr) {
        boolean hover = mx >= x && mx <= x + width && my >= y && my <= y + height;
        int bg = module.isEnabled() ? Theme.ACCENT_DIM : (hover ? Theme.HOVER : 0x00000000);
        if (bg != 0) {
            RenderUtil.fill(ctx, x, y, width, height, bg);
        }
        int color = module.isEnabled() ? Theme.ENABLED : Theme.TEXT;
        ctx.drawText(tr, module.name, (int) (x + 4), (int) (y + 4), color, false);
    }

    public boolean mouseClicked(double mx, double my, int button) {
        if (mx >= x && mx <= x + width && my >= y && my <= y + height) {
            if (button == 0) {
                module.toggle();
                return true;
            }
        }
        return false;
    }

    public void mouseReleased() {}
}
