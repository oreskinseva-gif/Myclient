package ru.dulovi.gui.components;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import ru.dulovi.Dulovi;
import ru.dulovi.module.Category;
import ru.dulovi.module.Module;
import ru.dulovi.util.RenderUtil;
import ru.dulovi.util.Theme;

import java.util.ArrayList;
import java.util.List;

public class Panel {
    public final Category category;
    public float x, y, width, headerHeight;
    public boolean extended = true;
    private final List<ModuleButton> buttons = new ArrayList<>();
    private boolean dragging;
    private double dragX, dragY;

    public Panel(Category category, float x, float y, float width, float headerHeight) {
        this.category = category;
        this.x = x;
        this.y = y;
        this.width = width;
        this.headerHeight = headerHeight;

        float by = y + headerHeight + 2;
        for (Module m : Dulovi.INSTANCE.moduleManager.getByCategory(category)) {
            buttons.add(new ModuleButton(m, x + 2, by, width - 4, 16));
            by += 18;
        }
    }

    public void render(DrawContext ctx, int mx, int my, float delta, TextRenderer tr) {
        float totalH = headerHeight + (extended ? buttons.size() * 18 + 4 : 0);

        // карточка
        RenderUtil.drawRoundedRect(ctx, x, y, width, totalH, 5, Theme.PANEL);
        // акцентная полоска
        RenderUtil.fill(ctx, x, y, width, 2, category.color);
        // заголовок
        ctx.drawText(tr, category.name, (int) (x + 6), (int) (y + 6), Theme.TEXT, false);

        if (extended) {
            float by = y + headerHeight + 2;
            for (ModuleButton b : buttons) {
                b.x = x + 2;
                b.y = by;
                b.render(ctx, mx, my, tr);
                by += 18;
            }
        }
    }

    public boolean mouseClicked(double mx, double my, int button) {
        if (mx >= x && mx <= x + width && my >= y && my <= y + headerHeight) {
            if (button == 1) {
                extended = !extended;
                return true;
            }
            if (button == 0) {
                dragging = true;
                dragX = mx - x;
                dragY = my - y;
                return true;
            }
        }
        if (extended) {
            for (ModuleButton b : buttons) {
                if (b.mouseClicked(mx, my, button)) return true;
            }
        }
        return false;
    }

    public void mouseReleased(double mx, double my, int button) {
        dragging = false;
        for (ModuleButton b : buttons) b.mouseReleased();
    }

    public void mouseDragged(double mx, double my) {
        if (dragging) {
            x = (float) (mx - dragX);
            y = (float) (my - dragY);
        }
    }
}
