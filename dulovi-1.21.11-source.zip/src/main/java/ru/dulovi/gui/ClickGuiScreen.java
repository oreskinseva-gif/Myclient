package ru.dulovi.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import ru.dulovi.Dulovi;
import ru.dulovi.gui.components.Panel;
import ru.dulovi.module.Category;
import ru.dulovi.util.RenderUtil;
import ru.dulovi.util.Theme;

import java.util.ArrayList;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private final List<Panel> panels = new ArrayList<>();

    public ClickGuiScreen() {
        super(Text.literal("dulovi"));
        float x = 18;
        for (Category cat : Category.values()) {
            panels.add(new Panel(cat, x, 28, 118, 20));
            x += 126;
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // тёмный фон в стиле Wild
        RenderUtil.fill(context, 0, 0, width, height, Theme.BG_DARK);

        // лёгкий акцент сверху
        RenderUtil.fill(context, 0, 0, width, 2, Theme.ACCENT);

        // название
        context.drawText(textRenderer, "dulovi", 12, 8, Theme.ACCENT, false);
        context.drawText(textRenderer, "v" + Dulovi.VERSION, 60, 8, Theme.TEXT_DIM, false);

        for (Panel p : panels) {
            p.render(context, mouseX, mouseY, delta, textRenderer);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        for (Panel p : panels) {
            if (p.mouseClicked(mouseX, mouseY, button)) return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        for (Panel p : panels) p.mouseReleased(mouseX, mouseY, button);
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
