package ru.dulovi.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class RotationUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static float[] getRotations(Entity target) {
        if (mc.player == null) return new float[]{0, 0};
        Vec3d eyes = mc.player.getEyePos();
        Vec3d pos = target.getPos().add(0, target.getHeight() * 0.5, 0);
        double diffX = pos.x - eyes.x;
        double diffY = pos.y - eyes.y;
        double diffZ = pos.z - eyes.z;
        double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(diffY, dist));
        return new float[]{MathHelper.wrapDegrees(yaw), MathHelper.clamp(pitch, -90f, 90f)};
    }

    public static void lookAt(Entity target) {
        if (mc.player == null) return;
        float[] rots = getRotations(target);
        mc.player.setYaw(rots[0]);
        mc.player.setPitch(rots[1]);
    }
}
