package ru.dulovi.util;

import net.minecraft.client.gui.DrawContext;

public class RenderUtil {
    // simple filled rect
    public static void fill(DrawContext ctx, float x, float y, float w, float h, int color) {
        ctx.fill((int) x, (int) y, (int) (x + w), (int) (y + h), color);
    }

    // rounded-ish by layered fills (lightweight, no GL)
    public static void drawRoundedRect(DrawContext ctx, float x, float y, float w, float h, float r, int color) {
        // center
        fill(ctx, x + r, y, w - r * 2, h, color);
        fill(ctx, x, y + r, w, h - r * 2, color);
        // corners approximated
        fill(ctx, x + r, y + r, w - r * 2, h - r * 2, color);
    }

    public static void drawOutline(DrawContext ctx, float x, float y, float w, float h, int color) {
        fill(ctx, x, y, w, 1, color);
        fill(ctx, x, y + h - 1, w, 1, color);
        fill(ctx, x, y, 1, h, color);
        fill(ctx, x + w - 1, y, 1, h, color);
    }
}
