package ru.dulovi.util;

public class Theme {
    // Wild-inspired dark palette with green accent
    public static final int BG = 0xE0101018;
    public static final int BG_DARK = 0xF00A0A12;
    public static final int PANEL = 0xE0161620;
    public static final int ACCENT = 0xFF00E5A0;
    public static final int ACCENT_DIM = 0xAA00E5A0;
    public static final int TEXT = 0xFFE8E8F0;
    public static final int TEXT_DIM = 0xFF8888A0;
    public static final int ENABLED = 0xFF00E5A0;
    public static final int HOVER = 0x22FFFFFF;
}
