package ru.dulovi.event;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class EventBus {
    private final Map<Class<? extends Event>, List<Consumer<? extends Event>>> listeners = new HashMap<>();

    public <T extends Event> void subscribe(Class<T> type, Consumer<T> listener) {
        listeners.computeIfAbsent(type, k -> new ArrayList<>()).add(listener);
    }

    @SuppressWarnings("unchecked")
    public <T extends Event> void post(T event) {
        List<Consumer<? extends Event>> list = listeners.get(event.getClass());
        if (list == null) return;
        for (Consumer<? extends Event> c : list) {
            ((Consumer<T>) c).accept(event);
            if (event.isCancelled()) break;
        }
    }
}
