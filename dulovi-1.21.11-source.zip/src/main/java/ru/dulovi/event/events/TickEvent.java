package ru.dulovi.event.events;

import ru.dulovi.event.Event;

public class TickEvent extends Event {
}
