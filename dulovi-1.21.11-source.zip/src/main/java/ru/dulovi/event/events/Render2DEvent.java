package ru.dulovi.event.events;

import net.minecraft.client.gui.DrawContext;
import ru.dulovi.event.Event;

public class Render2DEvent extends Event {
    public final DrawContext context;
    public final float tickDelta;

    public Render2DEvent(DrawContext context, float tickDelta) {
        this.context = context;
        this.tickDelta = tickDelta;
    }
}
