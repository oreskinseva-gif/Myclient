package ru.dulovi;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import ru.dulovi.event.EventBus;
import ru.dulovi.event.events.TickEvent;
import ru.dulovi.gui.ClickGuiScreen;
import ru.dulovi.module.ModuleManager;

public class Dulovi implements ClientModInitializer {
    public static Dulovi INSTANCE;
    public static final String NAME = "dulovi";
    public static final String VERSION = "1.0.0";

    public ModuleManager moduleManager;
    public EventBus eventBus;
    public KeyBinding clickGuiKey;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        eventBus = new EventBus();
        moduleManager = new ModuleManager();
        moduleManager.init();

        clickGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dulovi.clickgui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.dulovi"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (clickGuiKey.wasPressed() && client.player != null && client.currentScreen == null) {
                client.setScreen(new ClickGuiScreen());
            }
            if (client.player != null) {
                eventBus.post(new TickEvent());
                moduleManager.onTick();
            }
        });
    }
}
