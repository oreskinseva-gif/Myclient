package ru.dulovi.module;

import ru.dulovi.module.modules.combat.KillAura;
import ru.dulovi.module.modules.combat.Velocity;
import ru.dulovi.module.modules.movement.Fly;
import ru.dulovi.module.modules.movement.Speed;
import ru.dulovi.module.modules.movement.Sprint;
import ru.dulovi.module.modules.player.NoFall;
import ru.dulovi.module.modules.player.AutoTotem;
import ru.dulovi.module.modules.render.ESP;
import ru.dulovi.module.modules.render.Fullbright;
import ru.dulovi.module.modules.render.Tracers;
import ru.dulovi.module.modules.world.Scaffold;
import ru.dulovi.module.modules.misc.ClickGuiModule;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ModuleManager {
    public final List<Module> modules = new ArrayList<>();

    public void init() {
        // Combat
        modules.add(new KillAura());
        modules.add(new Velocity());

        // Movement
        modules.add(new Speed());
        modules.add(new Fly());
        modules.add(new Sprint());

        // Render
        modules.add(new ESP());
        modules.add(new Fullbright());
        modules.add(new Tracers());

        // World
        modules.add(new Scaffold());

        // Player
        modules.add(new NoFall());
        modules.add(new AutoTotem());

        // Misc
        modules.add(new ClickGuiModule());
    }

    public void onTick() {
        for (Module m : modules) {
            if (m.isEnabled()) m.onTick();
        }
    }

    public void onRender2D(net.minecraft.client.gui.DrawContext context, float tickDelta) {
        for (Module m : modules) {
            if (m.isEnabled()) m.onRender2D(context, tickDelta);
        }
    }

    public List<Module> getByCategory(Category cat) {
        return modules.stream().filter(m -> m.category == cat).collect(Collectors.toList());
    }

    public Module get(String name) {
        return modules.stream()
                .filter(m -> m.name.equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }
}
