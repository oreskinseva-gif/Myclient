package ru.dulovi.module;

public enum Category {
    COMBAT("Combat", 0xFFFF5555),
    MOVEMENT("Movement", 0xFF55FF55),
    RENDER("Render", 0xFF5555FF),
    WORLD("World", 0xFFFFAA00),
    PLAYER("Player", 0xFFAA55FF),
    MISC("Misc", 0xFFAAAAAA);

    public final String name;
    public final int color;

    Category(String name, int color) {
        this.name = name;
        this.color = color;
    }
}
