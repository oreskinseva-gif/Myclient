package ru.dulovi.module.modules.movement;

import net.minecraft.client.MinecraftClient;
import ru.dulovi.module.Category;
import ru.dulovi.module.Module;
import ru.dulovi.setting.ModeSetting;
import ru.dulovi.setting.NumberSetting;

public class Speed extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final ModeSetting mode = add(new ModeSetting("Mode", "BHop", "BHop", "Strafe"));
    private final NumberSetting boost = add(new NumberSetting("Boost", 0.25, 0.1, 0.6, 0.01));

    public Speed() {
        super("Speed", "Ускорение передвижения", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.input.movementForward == 0 && mc.player.input.movementSideways == 0) return;

        if (mode.get().equals("BHop")) {
            if (mc.player.isOnGround()) {
                mc.player.jump();
            }
            float yaw = mc.player.getYaw() * 0.017453292f;
            double speed = boost.get();
            mc.player.addVelocity(-Math.sin(yaw) * speed, 0, Math.cos(yaw) * speed);
        } else {
            // простой strafe
            float yaw = mc.player.getYaw() * 0.017453292f;
            double speed = boost.get() * 0.7;
            mc.player.addVelocity(-Math.sin(yaw) * speed, 0, Math.cos(yaw) * speed);
        }
    }
}
