package ru.dulovi.module.modules.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import ru.dulovi.module.Category;
import ru.dulovi.module.Module;
import ru.dulovi.setting.BoolSetting;
import ru.dulovi.util.RenderUtil;
import ru.dulovi.util.Theme;

public class ESP extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final BoolSetting players = add(new BoolSetting("Players", true));

    public ESP() {
        super("ESP", "Подсветка сущностей", Category.RENDER);
    }

    @Override
    public void onRender2D(DrawContext context, float tickDelta) {
        if (mc.world == null || mc.player == null || mc.gameRenderer == null) return;

        // простой 2D-бокс через проекцию (упрощённо — только индикация)
        // для полноценных 3D-боксов нужен world render mixin
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity p) || p == mc.player) continue;
            if (!players.get()) continue;
            if (!p.isAlive()) continue;

            // рисуем маленький маркер в углу как индикатор (placeholder)
            // реальный ESP делается через WorldRenderEvents или mixin на entity renderer
        }
    }
}
