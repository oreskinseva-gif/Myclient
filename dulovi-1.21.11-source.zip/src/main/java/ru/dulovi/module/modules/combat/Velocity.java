package ru.dulovi.module.modules.combat;

import net.minecraft.client.MinecraftClient;
import ru.dulovi.module.Category;
import ru.dulovi.module.Module;
import ru.dulovi.setting.NumberSetting;

public class Velocity extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final NumberSetting horizontal = add(new NumberSetting("Horizontal", 0.0, 0.0, 100.0, 1.0));
    private final NumberSetting vertical = add(new NumberSetting("Vertical", 0.0, 0.0, 100.0, 1.0));

    public Velocity() {
        super("Velocity", "Уменьшает отбрасывание", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        // простой вариант: если только что получили урон — гасим velocity
        if (mc.player.hurtTime > 0 && mc.player.hurtTime < 8) {
            double hx = horizontal.get() / 100.0;
            double vy = vertical.get() / 100.0;
            mc.player.setVelocity(
                    mc.player.getVelocity().x * hx,
                    mc.player.getVelocity().y * vy,
                    mc.player.getVelocity().z * hx
            );
        }
    }
}
