package ru.dulovi.module.modules.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import ru.dulovi.module.Category;
import ru.dulovi.module.Module;

public class NoFall extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public NoFall() {
        super("NoFall", "Отключает урон от падения", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.getNetworkHandler() == null) return;
        if (mc.player.fallDistance > 2.5f) {
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, false));
            mc.player.fallDistance = 0;
        }
    }
}
