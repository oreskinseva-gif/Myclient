package ru.dulovi.module.modules.movement;

import net.minecraft.client.MinecraftClient;
import ru.dulovi.module.Category;
import ru.dulovi.module.Module;
import ru.dulovi.setting.NumberSetting;

public class Fly extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final NumberSetting speed = add(new NumberSetting("Speed", 1.2, 0.3, 5.0, 0.1));

    public Fly() {
        super("Fly", "Полёт", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        mc.player.getAbilities().flying = true;
        mc.player.getAbilities().setFlySpeed(speed.getFloat() * 0.05f);

        double motionY = 0;
        if (mc.options.jumpKey.isPressed()) motionY = speed.get() * 0.4;
        if (mc.options.sneakKey.isPressed()) motionY = -speed.get() * 0.4;
        mc.player.setVelocity(mc.player.getVelocity().x, motionY, mc.player.getVelocity().z);
    }

    @Override
    protected void onDisable() {
        if (mc.player != null) {
            mc.player.getAbilities().flying = false;
        }
    }
}
