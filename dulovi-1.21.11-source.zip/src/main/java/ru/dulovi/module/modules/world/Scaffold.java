package ru.dulovi.module.modules.world;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.BlockItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import ru.dulovi.module.Category;
import ru.dulovi.module.Module;
import ru.dulovi.setting.BoolSetting;

public class Scaffold extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final BoolSetting tower = add(new BoolSetting("Tower", false));

    public Scaffold() {
        super("Scaffold", "Автомост", Category.WORLD);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        BlockPos below = mc.player.getBlockPos().down();
        if (!mc.world.getBlockState(below).isAir()) return;

        // ищем блок в хотбаре
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() instanceof BlockItem) {
                slot = i;
                break;
            }
        }
        if (slot == -1) return;

        int old = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = slot;

        BlockHitResult hit = new BlockHitResult(
                Vec3d.ofCenter(below),
                Direction.UP,
                below,
                false
        );
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        mc.player.swingHand(Hand.MAIN_HAND);

        mc.player.getInventory().selectedSlot = old;

        if (tower.get() && mc.options.jumpKey.isPressed()) {
            mc.player.setVelocity(mc.player.getVelocity().x, 0.42, mc.player.getVelocity().z);
        }
    }
}
