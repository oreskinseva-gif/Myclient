package ru.dulovi.module.modules.render;

import net.minecraft.client.MinecraftClient;
import ru.dulovi.module.Category;
import ru.dulovi.module.Module;

public class Fullbright extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();
    private double oldGamma = 1.0;

    public Fullbright() {
        super("Fullbright", "Максимальная яркость", Category.RENDER);
    }

    @Override
    protected void onEnable() {
        if (mc.options != null) {
            oldGamma = mc.options.getGamma().getValue();
            mc.options.getGamma().setValue(16.0);
        }
    }

    @Override
    protected void onDisable() {
        if (mc.options != null) {
            mc.options.getGamma().setValue(oldGamma);
        }
    }
}
