package ru.dulovi.module.modules.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import ru.dulovi.module.Category;
import ru.dulovi.module.Module;
import ru.dulovi.setting.BoolSetting;
import ru.dulovi.setting.NumberSetting;
import ru.dulovi.util.RotationUtil;

public class KillAura extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final NumberSetting range = add(new NumberSetting("Range", 4.2, 2.0, 6.0, 0.1));
    private final BoolSetting playersOnly = add(new BoolSetting("PlayersOnly", true));
    private final BoolSetting rotate = add(new BoolSetting("Rotate", true));

    public KillAura() {
        super("KillAura", "Автоатака ближайших сущностей", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        LivingEntity target = null;
        double closest = range.get();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity living) || living == mc.player) continue;
            if (!living.isAlive() || living.isInvisible()) continue;
            if (playersOnly.get() && !(living instanceof PlayerEntity)) continue;

            double dist = mc.player.distanceTo(living);
            if (dist < closest) {
                closest = dist;
                target = living;
            }
        }

        if (target != null) {
            if (rotate.get()) {
                RotationUtil.lookAt(target);
            }
            if (mc.player.getAttackCooldownProgress(0.5f) >= 1.0f) {
                mc.interactionManager.attackEntity(mc.player, target);
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        }
    }
}
