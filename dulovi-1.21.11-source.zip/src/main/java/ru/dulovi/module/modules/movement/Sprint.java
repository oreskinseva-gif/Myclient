package ru.dulovi.module.modules.movement;

import net.minecraft.client.MinecraftClient;
import ru.dulovi.module.Category;
import ru.dulovi.module.Module;

public class Sprint extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public Sprint() {
        super("Sprint", "Автоспринт", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.input.movementForward > 0 && !mc.player.isSneaking() && !mc.player.horizontalCollision) {
            mc.player.setSprinting(true);
        }
    }
}
