package ru.dulovi.module.modules.misc;

import ru.dulovi.module.Category;
import ru.dulovi.module.Module;

public class ClickGuiModule extends Module {
    public ClickGuiModule() {
        super("ClickGUI", "Меню клиента (Right Shift)", Category.MISC);
        // сам GUI открывается через бинд в Dulovi
    }
}
