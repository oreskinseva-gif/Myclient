package ru.dulovi.module.modules.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import ru.dulovi.module.Category;
import ru.dulovi.module.Module;
import ru.dulovi.setting.BoolSetting;

public class Tracers extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final BoolSetting players = add(new BoolSetting("Players", true));

    public Tracers() {
        super("Tracers", "Линии к сущностям", Category.RENDER);
    }

    @Override
    public void onRender2D(DrawContext context, float tickDelta) {
        // placeholder — полноценные tracers требуют world-space линии через RenderSystem
        // здесь только регистрация модуля, логика добавляется через mixin WorldRenderer
    }
}
