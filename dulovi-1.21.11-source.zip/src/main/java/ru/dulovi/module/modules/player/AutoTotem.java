package ru.dulovi.module.modules.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import ru.dulovi.module.Category;
import ru.dulovi.module.Module;

public class AutoTotem extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public AutoTotem() {
        super("AutoTotem", "Автоматически ставит тотем в offhand", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;

        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                int slot = i < 9 ? i + 36 : i;
                mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, mc.player);
                break;
            }
        }
    }
}
