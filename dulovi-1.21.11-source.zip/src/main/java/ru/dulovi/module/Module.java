package ru.dulovi.module;

import ru.dulovi.setting.Setting;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public final String description;
    public final Category category;
    private boolean enabled;
    public int key = -1;
    public final List<Setting<?>> settings = new ArrayList<>();

    public Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean state) {
        if (enabled == state) return;
        enabled = state;
        if (enabled) onEnable();
        else onDisable();
    }

    public boolean isEnabled() {
        return enabled;
    }

    protected void onEnable() {}
    protected void onDisable() {}

    public void onTick() {}
    public void onRender2D(net.minecraft.client.gui.DrawContext context, float tickDelta) {}
    public void onRender3D(float tickDelta) {}

    protected <T extends Setting<?>> T add(T setting) {
        settings.add(setting);
        return setting;
    }
}
